# -*- coding: utf-8 -*-
"""
Created on Thu Aug 10 12:47:18 2023

@author: pspea
"""

import random
import numpy as np
from scipy.stats import fisher_exact
from scipy.stats import mannwhitneyu

#DESEQ2 mrna for RSC4
cnv_list = [-0.633482966159613]
cnn_list = [-0.438083922, -0.585934693, -0.326769896]

U1, p = mannwhitneyu(cnv_list, cnn_list, method="exact")
ratio = np.median(cnv_list)/np.median(cnn_list) #1.446031078400574 0.5

print(ratio, p)

def fet_life(a,b,c,d):
        
    odds, p = fisher_exact([[a, b],
                               [c, d]], alternative='two-sided')
    
    ratio = round((a/b)/(c/d), 5)
    pval = round(p, 5)
    
    print(ratio, pval, p)
    

#enrichment in ms_rpf for cnv_regulation
cnv_is_down = sum([4])
cnv_not_down = sum([79])
cnn_is_down = sum([67, 31, 65, 75])
cnn_not_down = sum([4039, 4035, 3936, 3839])

fet_life(cnv_is_down, cnv_not_down, cnn_is_down, cnn_not_down)

#enrichment in ms_rna for cnv down_regulation
cnv_is_down = sum([42, 60, 13, 70])
cnv_not_down = sum([41, 9, 4, 11])
cnn_is_down = sum([12, 8, 71, 48])
cnn_not_down = sum([	4119,4121, 3937, 3981])

fet_life(cnv_is_down, cnv_not_down, cnn_is_down, cnn_not_down)

#enrichment in cnv for manually called uorfs
cnv_w_uorf = sum([55]) 
cnv_no_uorf = sum([58])
chr12_w_uorf = sum([84])
chr12_no_uorf = sum([127])

fet_life(cnv_w_uorf, cnv_no_uorf, chr12_w_uorf, chr12_no_uorf)

#enrichment in xeff_cnv for manually called uorfs
xeff_cnv = sum([48]) 
cnv_no_uorf = sum([43])
chr12_w_uorf = sum([84])
chr12_no_uorf = sum([127])

fet_life(cnv_w_uorf, cnv_no_uorf, chr12_w_uorf, chr12_no_uorf)

#enrichment in xeff_sig for manually called uorfs
xeff_w_uorf = sum([108, 89]) #1e2 set, #1e3 set
xeff_no_uorf = sum([88, 63])
chr12_w_uorf = sum([84])
chr12_no_uorf = sum([127])

fet_life(xeff_w_uorf, xeff_no_uorf, chr12_w_uorf, chr12_no_uorf)

#enrichment in SSD1_Bayne for manually called uorfs
xeff_w_uorf = sum([70]) #1e2 set, #1e3 set
xeff_no_uorf = sum([52])
chr12_w_uorf = sum([85])
chr12_no_uorf = sum([126])

fet_life(xeff_w_uorf, xeff_no_uorf, chr12_w_uorf, chr12_no_uorf) #1.99548 0.00303

#enrichment in SSD1_Bayne_42+30,42 for manually called uorfs
xeff_w_uorf = sum([46]) #1e2 set, #1e3 set
xeff_no_uorf = sum([27])
chr12_w_uorf = sum([85])
chr12_no_uorf = sum([126])

fet_life(xeff_w_uorf, xeff_no_uorf, chr12_w_uorf, chr12_no_uorf) #2.52549 0.00102

#enrichment in SSD1_Bayne_30 for manually called uorfs
xeff_w_uorf = sum([24]) #1e2 set, #1e3 set
xeff_no_uorf = sum([25])
chr12_w_uorf = sum([85])
chr12_no_uorf = sum([126])

fet_life(xeff_w_uorf, xeff_no_uorf, chr12_w_uorf, chr12_no_uorf) #1.42306 0.33499

#enrichment in SSD1_Bayne_42 for manually called uorfs
xeff_w_uorf = sum([15]) #1e2 set, #1e3 set
xeff_no_uorf = sum([16])
chr12_w_uorf = sum([85])
chr12_no_uorf = sum([126])

fet_life(xeff_w_uorf, xeff_no_uorf, chr12_w_uorf, chr12_no_uorf) #1.38971 0.43728

#enrichment in SSD1_Bayne_30,42 for manually called uorfs
xeff_w_uorf = sum([31]) #1e2 set, #1e3 set
xeff_no_uorf = sum([11])
chr12_w_uorf = sum([85])
chr12_no_uorf = sum([126])

fet_life(xeff_w_uorf, xeff_no_uorf, chr12_w_uorf, chr12_no_uorf) #4.17754 8e-05

#enrichment in SSD1_motif and xeff_sig overlap for manually called uorfs
ssd1_xeff_w_uorf = sum([19]) #1e2 set, #1e3 set
xeff_w_uorf = sum([245])
ssd1_xeff_wo_uorf = sum([5])
xeff_wo_uorf = sum([201])

fet_life(ssd1_xeff_w_uorf, xeff_wo_uorf, ssd1_xeff_wo_uorf, xeff_wo_uorf) #49.0 0.0 4.230562805935719e-46

#change in number of significantly different RNA genes between generations?
sig_g250 = np.median([1949, 1531])
sig_g150 = np.median([436, 655])
insig_g250 = np.median([4236-1949, 4236-1531])
insig_g150 = np.median([4236-436, 4236-655])

fet_life(sig_g250, insig_g250, sig_g150, insig_g150)

#change in number of significantly different RPF genes between generations?
sig_g250 = np.median([1635, 1126])
sig_g150 = np.median([255, 467])
insig_g250 = np.median([4236-1635, 4236-1126])
insig_g150 = np.median([4236-255, 4236-467])

fet_life(sig_g250, insig_g250, sig_g150, insig_g150)

#change in number of significantly different Protein genes between generations?
sig_g250 = np.median([482, 405])
sig_g150 = np.median([1424, 731])
insig_g250 = np.median([4236-482, 4236-405])
insig_g150 = np.median([4236-1424, 4236-731])

fet_life(sig_g150, insig_g150, sig_g250, insig_g250)

#change in number of significantly different teff genes between generations?
DGY1726=263
DGY1735=279
DGY1741=476
DGY1743=537

sig_g250 = np.median([DGY1741, DGY1743])
sig_g150 = np.median([DGY1726, DGY1735])
insig_g250 = np.median([4236-DGY1741, 4236-DGY1743])
insig_g150 = np.median([4236-DGY1726, 4236-DGY1735])

fet_life(sig_g250, insig_g250, sig_g150, insig_g150)

#change in number of significantly different pteff genes between generations?
DGY1726=85
DGY1735=109
DGY1741=219
DGY1743=200

sig_g250 = np.median([DGY1741, DGY1743])
sig_g150 = np.median([DGY1726, DGY1735])
insig_g250 = np.median([4236-DGY1741, 4236-DGY1743])
insig_g150 = np.median([4236-DGY1726, 4236-DGY1735])

fet_life(sig_g250, insig_g250, sig_g150, insig_g150)

#change in number of significantly different xeff genes between generations?
DGY1726=76
DGY1735=106
DGY1741=259
DGY1743=244

sig_g250 = np.median([DGY1741, DGY1743])
sig_g150 = np.median([DGY1726, DGY1735])
insig_g250 = np.median([4236-DGY1741, 4236-DGY1743])
insig_g150 = np.median([4236-DGY1726, 4236-DGY1735])

fet_life(sig_g250, insig_g250, sig_g150, insig_g150)





def two_way(total, left, right, obs, sim=10000):
    random_bag = range(total)
    sig_fig = len(str(int(sim)))-1

    by_chance_list = []
    exp_list = []

    for i in range(int(sim)):
        
        left_set = set(random.sample(random_bag, left))
        
        right_set = set(random.sample(random_bag, right))
        
        intersect = left_set.intersection(right_set)
        
        exp = len(intersect)
        
        if exp >= obs:
            by_chance_list.append(1)
        else:
            by_chance_list.append(0)
            
        exp_list.append(exp)
    
    exp_median = np.median(exp_list)    
    
    if exp_median != 0:
        ratio = round(obs/exp_median, 3) 
    else:
        ratio = obs
        
    outline = ('Median exp: {exp}, Num obs: {obs}, ratio: {ratio}, pval:{pval}\n').format(
        exp = exp_median,
        obs = obs,
        ratio = ratio,
        pval = round(sum(by_chance_list)/len(by_chance_list), sig_fig)
        )
    
    print(outline)
    
def two_way_deenrichment(total, left, right, obs, sim=10000):
    random_bag = range(total)
    sig_fig = len(str(int(sim)))-1

    by_chance_list = []
    exp_list = []

    for i in range(int(sim)):
        
        left_set = set(random.sample(random_bag, left))
        
        right_set = set(random.sample(random_bag, right))
        
        intersect = left_set.intersection(right_set)
        
        exp = len(intersect)
        
        if exp < obs:
            by_chance_list.append(1)
        else:
            by_chance_list.append(0)
            
        exp_list.append(exp)
    
    exp_median = np.median(exp_list)    
    
    if obs != 0:
        ratio = round(exp_median/(obs), 3) 
    else:
        ratio = exp_median
        
    outline = ('Median exp: {exp}, Num obs: {obs}, denrichment ratio: {ratio}, pval:{pval}\n').format(
        exp = exp_median,
        obs = obs,
        ratio = ratio,
        pval = round(sum(by_chance_list)/len(by_chance_list), sig_fig)
        )
    
    print(outline)

# def three_way(total, left, right, bottom, obs, sim=10000):
#     random_bag = range(total)
#     sig_fig = len(str(int(sim/100)))-1

#     by_chance_list = []

#     for i in range(int(sim)):
        
#         left_set = set(random.sample(random_bag, left))
        
#         right_set = set(random.sample(random_bag, right))
        
#         bottom_set = set(random.sample(random_bag, bottom))
        
#         intersect = left_set.intersection(right_set)
        
#         intersect = intersect.intersection(bottom_set)
        
#         if len(intersect) >= obs:
#             by_chance_list.append(1)
#         else:
#             by_chance_list.append(0)

    
#     print(sum(by_chance_list))
#     print(len(by_chance_list))
#     print(round(sum(by_chance_list)/len(by_chance_list), sig_fig)

#4C
two_way(1893, 56, 94, 7) # yes - pval 0.0177
    
#Are the ssd1_motif_hits enriched in ssd1_targets
total_genes = 6119
ssd1_targets = 154
ssd1_en = 186
overlap = 19
two_way(total_genes, ssd1_targets, ssd1_en, overlap, 1e4) # yes - Median exp: 1.0, Num obs: 9, ratio: 9.0, pval:0.0001

#Are the ssd1_motif_hits enriched in ssd1_targets_with_uorfs?
total_genes = 6119
ssd1_targets = 28
ssd1_en = 186
overlap = 9
two_way(total_genes, ssd1_targets, ssd1_en, overlap) # yes - Median exp: 1.0, Num obs: 9, ratio: 9.0, pval:0.0

#Are the ssd1_motif_hits enriched in significantly different expression efficiency genes (CNN + CNV)?
total_genes = 4236
xeff_sig = 411
ssd1_en = 130
overlap = 24
two_way(total_genes, xeff_sig, ssd1_en, overlap) # yes - Median exp: 12.0, Num obs: 24, ratio: 2.0, pval:0.0011

#Are the ssd1_motif_hits enriched in significantly different expression efficiency genes (CNN)?
total_genes = 4236
xeff_sig = 327
ssd1_en = 130
overlap = 20
two_way(total_genes, xeff_sig, ssd1_en, overlap) # yes - Median exp: 10.0, Num obs: 20, ratio: 2.0, pval:0.0022

#Are the ssd1_motif_hits enriched in significantly different expression efficiency genes (CNV)?
total_genes = 4236
xeff_sig_cnv = 84
ssd1_en = 130
overlap = 4
two_way(total_genes, xeff_sig_cnv, ssd1_en, overlap) # no - Median exp: 2.0, Num obs: 4, ratio: 2.0, pval:0.256

#Are the ssd1_motif_hits enriched in significantly different expression efficiency genes (CNN CNV w/ uorf)?
total_genes = 4236
xeff_sig_uorf = 229
ssd1_en = 130
overlap = 19
two_way(total_genes, xeff_sig_uorf, ssd1_en, overlap) # yes - Median exp: 7.0, Num obs: 19, ratio: 2.714, pval:0.000136

#Are the ssd1_motif_hits de-enriched in significantly different expression efficiency genes without uorfs (CNN CNV w/0 uorf)?
total_genes = 4236
xeff_sig_no_uorf = 201
ssd1_en = 130
overlap = 5
two_way_deenrichment(total_genes, xeff_sig_no_uorf, ssd1_en, overlap, 1e6) #no - Median exp: 6.0, Num obs: 5, denrichment ratio: 1.2, pval:0.252023

#Are the ssd1_motif_hits de-enriched in significantly different high expression 1e3 protein efficiency genes without uorfs (CNN CNV w/0 uorf)?
total_genes = 4236
xeff_sig_no_uorf = 120
ssd1_en = 130
overlap = 0
two_way_deenrichment(total_genes, xeff_sig_no_uorf, ssd1_en, overlap) # yes - Median exp: 4.0, Num obs: 0, denrichment ratio: 4.0, pval:0.0

#Are the ssd1_motif_hits enriched in significantly different translation efficiency genes (CNN CNV)?
total_genes = 4236
xeff_sig = 815
ssd1_en = 130
overlap = 42
two_way(total_genes, xeff_sig, ssd1_en, overlap) # yes - Median exp: 7.0, Num obs: 19, ratio: 2.714, pval:0.0002

#Are the ssd1_targets enriched in CNVs?
total_genes = 4236
cnv = 110
ssd1_target = 45
overlap = 3
two_way(total_genes, cnv, ssd1_target, overlap) # Median exp: 1.0, Num obs: 3, ratio: 3.0, pval:0.1073

#Are the ssd1_targets enriched in CNVs?
total_genes = 4236
cnv = 110
ssd1_target = 154
overlap = 3
two_way(total_genes, cnv, ssd1_target, overlap) # no - Median exp: 4.0, Num obs: 3, ratio: 0.75, pval:0.7801

#Are the ssd1_targets enriched in significantly different protein efficiency genes?
total_genes = 4236
xeff_sig = 411
ssd1_target = 96
overlap = 22
two_way(total_genes, cnv, ssd1_target, overlap) # Median exp: 1.0, Num obs: 3, ratio: 3.0, pval:0.1073

#Are the ssd1_targets enriched in significantly different protein efficiency genes?
total_genes = 4236
xeff_sig_uorfs = 237
ssd1_target = 96
overlap = 16
two_way(total_genes, cnv, ssd1_target, overlap) # Median exp: 1.0, Num obs: 3, ratio: 3.0, pval:0.1073



#Are the ssd1_motif_hits enriched in significantly different protein efficiency genes (CNV)?
two_way(1893, 56, 35, 2, 1e5) # no - pval 0.279

#Are the ssd1_targets enriched in significantly different protein efficiency genes (CNV)?
two_way(1893, 94, 35, 5, 1e6) # Median exp: 2.0, Num obs: 5, ratio: 2.5, pval:0.027

#
#Are the ssd1_motif_hits enriched in significantly different protein efficiency genes (CNN w/ uORF)?
two_way(1893, 56, 89, 6) # yes - pval 0.044

#Are the ssd1_targets enriched in significantly different protein efficiency genes (CNN w/ uORF)?
two_way(1893, 94, 89, 10) # yes - pval 0.0107

#Are the ssd1_motif_hits enriched in significantly different protein efficiency genes (CNV w/ uORF)?
two_way(1893, 56, 23, 2) # no - 0.1498

#Are the ssd1_targets enriched in significantly different protein efficiency genes (CNV w/ uORF)?
two_way(1893, 94, 23, 3) # no - pval 0.1021

#ssd1_motif_hits enriched versus the combine all sig_diff peff genes:
two_way(1893, 56, (153+35), (6+2), 1e5) # no - pval:0.297

#combine all uorfs
#Are the ssd1_motif_hits enriched in significantly different protein efficiency genes (w/ uORF)?
two_way(1893, 56, 112, 8, 1e6) # yes - pval:0.02

'''
can't do this until all genes are evaluated
'''
# #Are the xeff_sig genes enriched in manually called uORFs? 
# total_genes = 4236
# xeff_sig = 18
# ykl_uorfs = 86
# two_way(212, 18, 86, 10)
# # no - 0.1298
# two_way(1893, 56, 112, 8, 1e6) # yes - pval:0.02

#Are the ssd1_targets enriched in significantly different protein efficiency genes (w/ uORF)?
two_way(1893, 94, 112, 13, 1e6) # yes - 0.0028

#combine ssd1_motif_and_ssd1_targets and uORFs
#Are the ssd1_motif_hits enriched in significantly different protein efficiency genes (CNV w/ uORF)?
two_way(1893, 135, 112, 14, 1e4) # yes/no - 0.0492/0.05055

#are the ssd1_motif_and_ssd1_targets also associated with the YKL uorfs?
total_ykl_genes = 212
ssd1_motif_and_ssd1_targets = 18
ykl_uorfs = 86
two_way(212, 18, 86, 10)
# no - 0.1298
two_way(212, 8, 86, 3)

##are the teff_sig and uORFs from previous studies overlapping?
total_genes = 4236
tEFF_sig = 815
just_SN_uORFs = 610
overlap = 154
two_way(4236, 815, 610, 154, 1e6) # Median exp: 117.0, Num obs: 154, ratio: 1.316, pval:0.0001

#large scale back to match the limited number tested in May 2023
total_genes = 559
tEFF_sig = 82
just_May_uORFs = 524
overlap = 71
two_way(total_genes, tEFF_sig, just_May_uORFs, overlap, 1e4) #Median exp: 49.0, Num obs: 71, ratio: 1.449, pval:0.0

##are the pteff_sig and uORFs from previous studies overlapping?
total_genes = 4236
ptEFF_sig = 353
just_SN_uORFs = 610
overlap = 73
two_way(total_genes, ptEFF_sig, just_SN_uORFs, overlap, 1e5) #Median exp: 51.0, Num obs: 73, ratio: 1.431, pval:0.0003

#large scale back to match the limited number tested in May 2023
total_genes = 559
ptEFF_sig = 52
just_May_uORFs = 524
overlap = 47
two_way(total_genes, ptEFF_sig, just_May_uORFs, overlap, 1e5) # Median exp: 49.0, Num obs: 47, ratio: 0.959, pval:0.90243

##are the xteff_sig and uORFs from previous studies overlapping?
total_genes = 4236
xtEFF_sig = 411
just_SN_uORFs = 610
overlap = 85
two_way(total_genes, xtEFF_sig, just_SN_uORFs, overlap, 1e5) #Median exp: 59.0, Num obs: 85, ratio: 1.441, pval:0.00017

#large scale back to match the limited number tested in May 2023
total_genes = 559
ptEFF_sig = 55
just_May_uORFs = 524
overlap = 48
two_way(total_genes, ptEFF_sig, just_May_uORFs, overlap, 1e4) # Median exp: 117.0, Num obs: 154, ratio: 1.316, pval:0.0001


###

##are the xteff_sig_filtered and SN_uORFs from previous studies overlapping?
total_genes = (4236-359)
xtEFF_sig_f = 52
manual_uORFs = 610
overlap = 10
two_way(total_genes, xtEFF_sig_f, manual_uORFs, overlap, 1e5) #Median exp: 59.0, Num obs: 85, ratio: 1.441, pval:0.00017

##are the xteff_sig_dosage_compensated and uORFs from previous studies overlapping?
total_genes = 91
xtEFF_sig_dc = 37
just_SN_uORFs = 34
overlap = 5
two_way(total_genes, xtEFF_sig_dc, just_SN_uORFs, overlap, 1e5) 

##are the xteff_sig_dosage_compensated and manual uORFs from previous studies overlapping?
total_genes = 91
xtEFF_sig_dc = 37
manual_uORFs = 23
overlap = 9
two_way(total_genes, xtEFF_sig_dc, manual_uORFs, overlap, 1e5) 

##are the SSD1_en and DC genes overlapping?
#RNA
total_genes = 4236
RNA = 7
ssd1 = 141
overlap = 0
two_way(total_genes, RNA, ssd1, overlap) #Median exp: 1.0, Num obs: 0, ratio: 0.0, pval:1.0

#tEff
total_genes = 4236
RPF = 4
ssd1 = 141
overlap = 1
two_way(total_genes, RPF, ssd1, overlap) #Median exp: 0.0, Num obs: 1, ratio: 1, pval:0.3851

#xEFF
total_genes = 4236
xeff = 39
ssd1 = 141
overlap = 2
two_way(total_genes, xeff, ssd1, overlap) #Median exp: 4.0, Num obs: 4, ratio: 1.0, pval:0.6428

#ptEFF
total_genes = 4236
ptEFF = 44
ssd1 = 141
overlap = 2
two_way(total_genes, ptEFF, ssd1, overlap) #Median exp: 4.0, Num obs: 4, ratio: 1.0, pval:0.6428