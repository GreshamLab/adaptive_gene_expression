# -*- coding: utf-8 -*-
"""
Created on Sat Sep 16 13:17:36 2023

make two histograms or maybe violin plots ??? ()

@author: pspea
"""

import plotly.io as pio
pio.renderers.default = "browser"

import pandas as pd

import plotly.graph_objects as go

from scipy.stats import mannwhitneyu

def populate_hist_dict(infile_name, source):
    global ssd_df
    
    infile = open(infile_name)
    ssd_df[source] = 'ns'

    for line in infile:
        gene = line.strip()
        
        if gene in ssd_df.index:
            ssd_df.at[gene, source] = source

    infile.close()

def mwu_test(exp, control):
    global ssd_df
    
    exp_list = ssd_df[(ssd_df[exp] == exp)]['oe'].tolist()
    control_list = ssd_df[(ssd_df[control] == control)]['oe'].tolist()
    
    U1, p = mannwhitneyu(exp_list, control_list)
        
    print(exp, control, p)
    
ssd_file_name = ("data/SSD1_hits_in_TL_from_SGD_SN.txt")
ssd_df = pd.read_table(ssd_file_name, index_col=0)
ssd_dict = ssd_df.to_dict('index')

#ssd_df['oe'] = np.log2((ssd_df['hits']/ssd_df['length'])-(ssd_df['exp_hits']/ssd_df['length']))
ssd_df['oe'] = (ssd_df['hits'])-(ssd_df['exp_hits'])

infile_name = ('data/hist_YKL_all.txt')
source = 'YKL'
populate_hist_dict(infile_name, source)

infile_name = ('data/hist_all_SSD1_targets.txt')
source = 'SSD1_targets'
populate_hist_dict(infile_name, source)

infile_name = ('data/hist_Bayne_SSD1_targets.txt')
source = 'SSD1_targets_bayne_all'
populate_hist_dict(infile_name, source)

infile_name = ('data/hist_Bayne_SSD1_uORFs_targets.txt')
source = 'SSD1_targets_bayne_uorfs'
populate_hist_dict(infile_name, source)

infile_name = ('data/hist_xeff_1e2.txt')
source = 'genome_wide'
populate_hist_dict(infile_name, source)

infile_name = ('data/hist_xeff_1e2_sig.txt')
source = 'xeff_1e2_sig'
populate_hist_dict(infile_name, source)

infile_name = ('data/hist_xeff_1e2_no_uORF.txt')
source = 'xeff_1e2_sig_no_uORF'
populate_hist_dict(infile_name, source)

infile_name = ('data/hist_xeff_1e2_not_sig_uORF.txt')
source = 'xeff_1e2_not_sig_uORF'
populate_hist_dict(infile_name, source)

infile_name = ('data/hist_xeff_1e2_uORF.txt')
source = 'xeff_1e2_sig_uORF'
populate_hist_dict(infile_name, source)

output_figure_name = ('data/hist_SSD1_uORF.pdf')
fig = go.Figure()

source_list = ['genome_wide', 'SSD1_targets', 'SSD1_targets_bayne_all', 
               'SSD1_targets_bayne_uorfs', 'xeff_1e2_sig', 'xeff_1e2_sig_no_uORF', 
               'xeff_1e2_not_sig_uORF', 'xeff_1e2_sig_uORF']

for source in source_list:
    fig.add_trace(go.Violin(x=ssd_df[source][ssd_df[source] == source],
                            y=ssd_df['oe'][ssd_df[source] == source],
                            name=source,
                            box_visible=True,
                            meanline_visible=False))

fig.show()
fig.write_image(output_figure_name)

for source in source_list:
    if source != 'genome_wide':
        mwu_test(source, 'genome_wide')
        

mwu_test('xeff_1e2_sig_uORF', 'xeff_1e2_not_sig_uORF')
