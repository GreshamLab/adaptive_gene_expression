# -*- coding: utf-8 -*-
"""
Created on Wed Nov  2 12:05:39 2022

@author: pspea
"""
import numpy as np
import pandas as pd

#import plotly.graph_objects as go

import plotly.io as pio
pio.renderers.default = "browser"


import plotly.graph_objects as go

strain_list = ['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']
#We need to populate the gene list with those genes that are detected in every strain - 
# otherwise there will be misalignement on between genes between strains on the global heatmap

copy_number_filename = ('data/chemostat_gene_relative_copy_number.tsv')
df = pd.read_table(copy_number_filename, index_col=0)
cn_dict = df.to_dict('index')

strain_list = ['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']
#We need to populate the gene list with those genes that are detected in every strain - 
# otherwise there will be misalignement on between genes between strains on the global heatmap

genes_to_remove_filename = ('data/Transposable_elements_rDNA.txt')
df = pd.read_table(genes_to_remove_filename, index_col=0)
genes_to_remove_dict = df.to_dict('index')

gene_count_strain = {}

for istype in ['Obs']:
    for evo_strain in strain_list:
        if evo_strain != 'DGY1657':
            infile = ('data/{}_global_expression.tsv').format(evo_strain)
            #deseq_results_file = open(infile)
            df = pd.read_table(infile, index_col=0)
            deseq_results = df.to_dict('index')
            
            for gene in deseq_results:
                if (gene[0] == 'Y') and (gene not in genes_to_remove_dict):
                    if gene not in gene_count_strain:
                        gene_count_strain[gene] = set()
                        
                    gene_count_strain[gene].add(evo_strain)
                    
                    
complete_gene_list = set()
strain_max = 0

for gene in gene_count_strain:
    if len(gene_count_strain[gene]) >= strain_max:
        strain_max = len(gene_count_strain[gene])
    
    if len(gene_count_strain[gene]) >= 4:
        complete_gene_list.add(gene)
    else:
        print(gene)
                         
ykl_list = []
ykr_list = []
for gene in complete_gene_list:
    if 'YKL' in gene:
        ykl_list.append(gene)
    if 'YKR' in gene:
        ykr_list.append(gene)

ykr_list.sort()
ykl_list.sort(reverse=True)

#yk_list = ykl_list + ykr_list

yk_list = ykr_list

exp = []

for strain in strain_list:
    exp_sub = []
    for gene in yk_list:
        exp_sub.append(round(cn_dict[gene][strain]))
    exp.append(exp_sub)
        
        
output_figure_name = ('data/heatmap_CNV_map.pdf')

fig = go.Figure(data=go.Heatmap(
                   z=exp,
                   x=yk_list,
                   y=strain_list,
                   hoverongaps = False,
                   colorscale= 'Reds'))
fig.show()
#fig.write_image(output_figure_name)

# colorscale= 'RdBu_r'

# deseq_results_filename =  ('C:/Gresham/tiny_projects/Project_Grace/insertions/global_normalized_insertionPerGene.txt')
# deseq_results_file = open(deseq_results_filename)
# df = pd.read_table(deseq_results_filename, index_col=0)
# deseq_results = df.to_dict('index')

# anc_adundance = {}

# for evo_strain in ['DGY1657']:        
#     for gene in yk_list:
#         #if deseq_results[gene]['FDR.anc_evo'] <= 0.05:
#             if gene not in anc_adundance:
#                 anc_adundance[gene] = {}
                
#                 if gene in deseq_results:
#                     anc_adundance[gene] = deseq_results[gene]['DGY1657']
#                 else:
#                     anc_adundance[gene] = 0


# for evo_strain in strain_list:        
#     print(evo_strain)
#     for gene in yk_list:
#         #if deseq_results[gene]['FDR.anc_evo'] <= 0.05:
#             if gene not in log2fc_dict:
#                 log2fc_dict[gene] = {}
                
#             if gene in deseq_results:
#                 log2fc_dict[gene][evo_strain] = np.log2(deseq_results[gene][evo_strain] / anc_adundance[gene])
#             else:
#                 log2fc_dict[gene][evo_strain] = 0

def return_type_specific_column_names(read_type):
    if read_type == 'RNA':
        return("rna_scale_robust", "rna_sig", "rna_padj")
    if read_type == 'RPF':
        return("rpf_scale_robust", "rpf_sig", "rpf_padj")
    if read_type == 'MS':
        return("ms_scale_robust", "ms_sig", "ms_padj") 


for read_type in ['RNA','RPF', 'MS']:
    
    output_figure_name = ('data/Log2FC_map_GR_{}_chrXI.pdf').format(read_type)

    log2fc_dict = {}
    
    expression_term, _sig_term, _padj_term = return_type_specific_column_names(read_type)
    
    for evo_strain in set(['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']):
        infile = ('data/{}_global_expression.tsv').format(evo_strain)
        df = pd.read_table(infile, index_col=0)
        robust_dict = df.to_dict('index')
        
        for gene in yk_list:
            if gene not in log2fc_dict:
                log2fc_dict[gene] = {}
            
            log2fc_dict[gene][evo_strain] = robust_dict[gene][expression_term]

    exp = []                                                
    for strain in strain_list:
        exp_sub = []
        for gene in yk_list:
            if gene in log2fc_dict:
                if strain in log2fc_dict[gene]:
                    exp_sub.append(log2fc_dict[gene][strain])
                else:
                    exp_sub.append(0)
                    print(gene, strain)
                    1/0
        exp.append(exp_sub)
        
    fig = go.Figure(data=go.Heatmap(
                       z=exp,
                       x=yk_list,
                       y=strain_list,
                       hoverongaps = False,
                       zmin=-10,
                       zmax=10,
                       colorscale= 'RdBu_r'))
    
    plot_title = ('{}').format(read_type)
    fig.update_layout(
        title=plot_title,
        xaxis_title="Gene",
        yaxis_title="Strain",
        font=dict(
            size=18,
            color="Black"
        )
    )
    
    fig.show()

    #fig.write_image(output_figure_name)
    

for evo_strain in set(['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']): 
    log2fc_dict = {}
    output_figure_name = ('data/Log2FC_map_GR_{}_chrXI.pdf').format(evo_strain)
    
    read_type = 'DNA'
    for gene in yk_list:
        if gene not in log2fc_dict:
            log2fc_dict[gene] = {}
            
        log2fc_dict[gene][read_type] = (10*round(cn_dict[gene][evo_strain]))/4
            
    for read_type in ['RNA','RPF', 'MS']:
        expression_term, _sig_term, _padj_term = return_type_specific_column_names(read_type)
        
        infile = ('data/{}_global_expression.tsv').format(evo_strain)
        df = pd.read_table(infile, index_col=0)
        robust_dict = df.to_dict('index')
        
        for gene in yk_list:
            if gene not in log2fc_dict:
                log2fc_dict[gene] = {}
            
            log2fc_dict[gene][read_type] = robust_dict[gene][expression_term]
    
    exp = []                                                
    for read_type in ['MS', 'RPF', 'RNA', 'DNA']:
        exp_sub = []
        for gene in yk_list:
            if gene in log2fc_dict:
                if read_type in log2fc_dict[gene]:
                    exp_sub.append(log2fc_dict[gene][read_type])
                else:
                    exp_sub.append(0)
                    print(gene, read_type)
                    1/0
        exp.append(exp_sub)
        
    fig = go.Figure(data=go.Heatmap(
                       z=exp,
                       x=yk_list,
                       y=['MS', 'RPF', 'RNA', 'DNA'],
                       hoverongaps = False,
                       zmin=-10,
                       zmax=10,
                       colorscale= 'RdBu_r'))
    
    plot_title = ('{}').format(evo_strain)
    fig.update_layout(
        title=plot_title,
        xaxis_title="Gene",
        yaxis_title="Expression level",
        font=dict(
            size=18,
            color="Black"
        )
    )
        
    fig.show()

    #fig.write_image(output_figure_name)
