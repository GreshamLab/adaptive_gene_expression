# -*- coding: utf-8 -*-
"""
Created on Tue Jun 20 08:48:17 2023

@author: pspea
"""
import plotly.io as pio
pio.renderers.default = "browser"

from scipy.stats import fisher_exact
import pandas as pd
import numpy as np

#
from sklearn.preprocessing import RobustScaler
from sklearn.preprocessing import StandardScaler
import statsmodels.stats.multitest as smt
#import statsmodels.api as sm

from scipy.stats import mannwhitneyu
import plotly.graph_objects as go
import plotly.express as px
#import pandas as pd
from scipy import stats

def calc_expected_ms(gene, strain, obs_list, observed_ms_dict):

    obs_column_name = ('ms_{}').format(strain) 
            
    if gene not in observed_ms_dict:
        observed_ms_dict[gene] = {}
    
    if strain not in observed_ms_dict[gene]:
        observed_ms_dict[gene][obs_column_name] = np.median(obs_list)
    else:
        print('error')
        1/0

    return(observed_ms_dict)
            
def gene_to_strain(index, strain, observed_ms_dict, obs_list, ms_dict):
    
    genes_to_remove_filename = ('C:/Gresham/Project_Carolino/metadata/Transposable_elements_rDNA.txt')
    genes_to_remove_df = pd.read_table(genes_to_remove_filename, index_col=0)
    genes_to_remove_dict = genes_to_remove_df.to_dict('index')
        
    gene = ms_dict[index]['Majority.protein.IDs']
    
    if gene[0] == 'Y':
        if ';' in gene:
            gene_list = gene.split(';')
            
            for gene in gene_list:
                if gene not in genes_to_remove_dict:
                    observed_ms_dict = calc_expected_ms(gene, strain, obs_list, observed_ms_dict)
        else:
            if gene not in genes_to_remove_dict:
                observed_ms_dict = calc_expected_ms(gene, strain, obs_list, observed_ms_dict)
            
    return(observed_ms_dict)


def make_observed_ms():
    # zscr_scalar = zscoreScaler()
    observed_ms_dict = {}

    for strain in ['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:

        infile = ('C:/Gresham/Project_Carolino_new/ms/{}_v_DGY1765_wCON_wBatch_QN_p0.01.txt').format(strain)
        df = pd.read_table(infile)
        ms_dict = df.to_dict('index')
                
        DGY1657_set = set(['2.A', '8.A', '14.A', '5.B', '11.B'])
        DGY1726_set = set(['3.A', '9.A', '15.A', '6.B', '12.B'])
        DGY1735_set = set(['5.A', '11.A', '2.B', '8.B', '14.B'])
        DGY1741_set = set(['6.A', '12.A', '3.B', '9.B', '15.B'])
        DGY1743_set = set(['7.A', '13.A', '4.B', '10.B', '16.B'])
        
        for index in ms_dict:
            DGY1657_list = []
            DGY1726_list = []
            DGY1735_list = []
            DGY1741_list = []
            DGY1743_list = []
            
            if strain == 'DGY1726':
                for rep in DGY1657_set:
                    col_name = ('Reporter.intensity.corrected.{}').format(rep)
                    DGY1657_list.append(ms_dict[index][col_name])
                observed_ms_dict = gene_to_strain(index, 'DGY1657', observed_ms_dict, DGY1657_list, ms_dict)
            
            if strain == 'DGY1726':                
                for rep in DGY1726_set:
                    col_name = ('Reporter.intensity.corrected.{}').format(rep)
                    DGY1726_list.append(ms_dict[index][col_name])
                observed_ms_dict = gene_to_strain(index, 'DGY1726', observed_ms_dict, DGY1726_list, ms_dict)

            if strain == 'DGY1735':                
                for rep in DGY1735_set:
                    col_name = ('Reporter.intensity.corrected.{}').format(rep)
                    DGY1735_list.append(ms_dict[index][col_name])
                observed_ms_dict = gene_to_strain(index, 'DGY1735', observed_ms_dict, DGY1735_list, ms_dict)

            if strain == 'DGY1741':                
                for rep in DGY1741_set:
                    col_name = ('Reporter.intensity.corrected.{}').format(rep)
                    DGY1741_list.append(ms_dict[index][col_name])
                observed_ms_dict = gene_to_strain(index, 'DGY1741', observed_ms_dict, DGY1741_list, ms_dict)   

            if strain == 'DGY1743':               
                for rep in DGY1743_set:
                    col_name = ('Reporter.intensity.corrected.{}').format(rep)
                    DGY1743_list.append(ms_dict[index][col_name])
                observed_ms_dict = gene_to_strain(index, 'DGY1743', observed_ms_dict, DGY1743_list, ms_dict)
    

    outfile_name = ('C:/Gresham/Project_Carolino/analyses/efficiency/ms_counts_expression.tsv')
    df = pd.DataFrame.from_dict(observed_ms_dict, orient='index')
    df = df.fillna(0)

    df.to_csv(outfile_name, sep = '\t')
    
    return(df)

def make_exp_tpm(df, sample_name, anc_name, strain):
    global cn_dict
    """
    convert read counts to TPM (transcripts per million)
    :param df: a dataFrame contains the result coming from featureCounts
    :param sample_name: a list, all sample names, same as the result of featureCounts
    :return: TPM
    """
    #result = df
    
    genes_to_remove_filename = ('C:/Gresham/Project_Carolino/metadata/Transposable_elements_rDNA.txt')
    genes_to_remove_df = pd.read_table(genes_to_remove_filename, index_col=0)
    genes_to_remove_dict = genes_to_remove_df.to_dict('index')
    
    result_dict = df.to_dict('index')
    
    for rem_gene in genes_to_remove_dict:
        if rem_gene in result_dict:
            del result_dict[rem_gene]
    
    total_rate = 0
        
    for gene in result_dict:
        if gene in cn_dict:
            cn = cn_dict[gene][strain]
        
            if sample_name in result_dict[gene]:
                nt_length = result_dict[gene]['nt_length']
                counts = result_dict[gene][anc_name] * cn
                total_rate += counts / nt_length
                
    tpm_name = ('{}_exp_tpm').format(sample_name)
    
    for gene in result_dict:
        if gene in cn_dict:
            cn = cn_dict[gene][strain]
        
            if sample_name in result_dict[gene]:
                nt_length = result_dict[gene]['nt_length']
                counts = result_dict[gene][anc_name] * cn
                rate = counts / nt_length
                result_dict[gene][tpm_name] = 1e6*(rate / total_rate)
                
    
            
    df = pd.DataFrame.from_dict(result_dict, orient='index')
    
    return(df, tpm_name)

def make_tpm(df, sample_name, strain):
    """
    convert read counts to TPM (transcripts per million)
    :param df: a dataFrame contains the result coming from featureCounts
    :param sample_name: a list, all sample names, same as the result of featureCounts
    :return: TPM
    """
    #result = df
    
    genes_to_remove_filename = ('C:/Gresham/Project_Carolino/metadata/Transposable_elements_rDNA.txt')
    genes_to_remove_df = pd.read_table(genes_to_remove_filename, index_col=0)
    genes_to_remove_dict = genes_to_remove_df.to_dict('index')
    
    result_dict = df.to_dict('index')
    
    for rem_gene in genes_to_remove_dict:
        if rem_gene in result_dict:
            del result_dict[rem_gene]
    
    total_rate = 0
        
    for gene in result_dict:
        if sample_name in result_dict[gene]:
            nt_length = result_dict[gene]['nt_length']
            counts = result_dict[gene][sample_name]
            total_rate += counts / nt_length
                
    tpm_name = ('{}_tpm').format(sample_name)
    
    for gene in result_dict:
        if sample_name in result_dict[gene]:
            nt_length = result_dict[gene]['nt_length']
            counts = result_dict[gene][sample_name]
            rate = counts / nt_length
            result_dict[gene][tpm_name] = 1e6*(rate / total_rate)
            
    df = pd.DataFrame.from_dict(result_dict, orient='index')
    
    return(df)


def plot_rna_log_rna_log_ratio(top, bottom):
    
    #import plotly.express as px
    
    '''
    let's make three boxplots for every efficiency, 
    one has background (no sigdiff, no CNV)
    one has sigdiff (sigdiff, no CNV)
    one has CNV (only CNV)
    '''
    
    compare = ("{}_v_{}").format(top, bottom)
        
    output_figure_name = ('C:/Gresham/Project_Carolino/analyses/efficiency/{top}_to_{bottom}_efficiency_pval_ratio.pdf').format(
        top = top, bottom = bottom)
    
    fig = go.Figure()
        
    list_ns = []
    list_cnv_sig = []
    list_cnv_ns = []
    list_cnv = []
    
    if compare == 'rna_v_rna':
        for strain in set(['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']):
            infile = ('C:/Gresham/Project_Carolino/analyses/chemostat_DESeq/DESeq_Exp_RNA_DGY1657_{strain}_v2.txt').format(
                strain = strain) 
            df = pd.read_table(infile, index_col=0)
            exp_dict = df.to_dict('index')
            
            for gene in exp_dict:
                if gene in cn_dict:
                    cn = cn_dict[gene][strain]
                    padj = exp_dict[gene]['padj'] 
                    val = exp_dict[gene]['log2FoldChange']
                    
                    if cn == 1:
                        list_ns.append(val)
                    
                    if cn > 1:
                        if padj <= 0.05:
                            list_cnv_sig.append(val)
                            list_cnv.append(val)
                        else:
                            list_cnv_ns.append(val)
                            list_cnv.append(val)
                            
    fig = go.Figure()

    fig.add_trace(go.Box(y=list_ns, name='CN = 1',
                         boxpoints='all',
                         jitter=0.3,
                         pointpos=-1.8,
                         marker_color = 'grey'))
    
    # fig.add_trace(go.Box(y=list_sig, name='Sig',
    #                      boxpoints='all',
    #                      jitter=0.3,
    #                      pointpos=-1.8,
    #                      marker_color = 'indianred'))
    
    fig.add_trace(go.Box(y=list_cnv_sig, name = 'CNV_sig',
                         boxpoints='all',
                         jitter=0.3,
                         pointpos=-1.8,
                         marker_color = 'blue'))
    
    fig.add_trace(go.Box(y=list_cnv_ns, name = 'CNV_ns',
                         boxpoints='all',
                         jitter=0.3,
                         pointpos=-1.8,
                         marker_color = 'grey'))
                  
    
    fig.update_layout(
        title=compare,
        xaxis_title="gene category",
        yaxis_title="Efficiency Ratio (Obs / Exp)",
        font=dict(
            size=18,
            color="Black"
        ),
        autosize=False,
        width=1000,
        height=800,
    
    )
    
    #fig.update_xaxes(range=[-4.5, 4.5])
    #fig.update_yaxes(range=[-5, 8])
    
    
    fig.show()
    fig.write_image(output_figure_name)
    from scipy import stats

        

    U1, p = stats.kruskal(list_cnv, list_ns)
    
    #U1, p = mannwhitneyu(list_cnv_sig, list_sig)
    #p = round(p,)
    ratio = round(np.median(list_cnv)/np.median(list_ns),3)
    med_cnv = round(np.median(list_cnv),3)
    med_cnn = round(np.median(list_ns),3)
    
    print('sig_cnv_v_cnn', strain, compare, med_cnv, med_cnn, ratio, p)
    
        #plot_log_log_scale('ms', 'rna', 'YBR169C')
    if False:
        plot_rna_log_rna_log_ratio('rna', 'rna')


def plot_log_log_ratio(top, bottom):
    
    #import plotly.express as px
    
    '''
    let's make three boxplots for every efficiency, 
    one has background (no sigdiff, no CNV)
    one has sigdiff (sigdiff, no CNV)
    one has CNV (only CNV)
    '''
    
    compare = ("{}_v_{}").format(top, bottom)
        
    output_figure_name = ('C:/Gresham/Project_Carolino/analyses/efficiency/{top}_to_{bottom}_efficiency_pval_ratio.pdf').format(
        top = top, bottom = bottom)
    
    fig = go.Figure()
        
    list_ns = []
    list_sig = []
    list_cnv_sig = []
    list_cnv_ns = []
    
    list_cnn = []
    list_cnv = []
    
    cnv_set = set()
    
    cnv_count_dict = {}
    
    if compare == 'rna_v_rna':
        for strain in set(['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']):
            infile = ('C:/Gresham/Project_Carolino/analyses/chemostat_DESeq/DESeq_Exp_RNA_DGY1657_{strain}_v2.txt').format(
                strain = strain) 
            df = pd.read_table(infile, index_col=0)
            exp_dict = df.to_dict('index')
            
            #for gene in set(['YKR008W']):
            for gene in exp_dict:
                if gene in cn_dict:
                    cn = cn_dict[gene][strain]
                    padj = exp_dict[gene]['padj'] 
                    val = exp_dict[gene]['log2FoldChange']
                    
                    if cn == 1:
                        if padj <= 0.05:
                            list_sig.append(val)
                            list_cnn.append(val)
                            
                            
                            
                        else:
                            list_ns.append(val)
                            list_cnn.append(val)
                    
                    if cn > 1:
                        

                        if padj <= 0.05:
                            list_cnv_sig.append(val)
                            list_cnv.append(val)
                            
                            if val < 0:
                                #cnv_set.add(gene)                        
                                if gene not in cnv_count_dict:
                                    cnv_count_dict[gene] = 0
                                cnv_count_dict[gene] += 1
                            
                        else:
                            list_cnv_ns.append(val)
                            list_cnv.append(val)
    
    # for gene in cnv_count_dict:
    #     if cnv_count_dict[gene] > 3:
    #         cnv_set.add(gene)
    # print(cnv_set)
                            
    else:
        
        infile = ('C:/Gresham/Project_Carolino/analyses/efficiency/{top}_to_{bottom}_ratio_1e2.tsv').format(
            top = top, bottom = bottom) 
        df = pd.read_table(infile, index_col=0)
        
        for strain in set(['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']):
            if strain != 'DGY1657':
                #zscr_scalar = zscoreScaler()
                
                infile = ('C:/Gresham/Project_Carolino/analyses/efficiency/{top}_to_{bottom}_ratio_1e2.tsv').format(
                    top = top, bottom = bottom) 
                df = pd.read_table(infile, index_col=0)
                
                
                cn_col_name = ('{}_copy_number').format(strain)
                df = df[df[cn_col_name] >= 1]
                
                if (top == 'rpf'):
                    anc_numerator_normalized_name = ('{}_DGY1657_tpm').format(top)
                    evo_numerator_normalized_name = ('{}_{}_tpm').format(top, strain)
                    
                if (top == 'ms'):
                    anc_numerator_normalized_name = ('ms_DGY1657')
                    evo_numerator_normalized_name = ('ms_{}').format(strain) 
                
                if (bottom == 'rna') or (bottom == 'rpf'):
                    anc_denomerator_normalized_name = ('{}_DGY1657_tpm').format(bottom)
                    evo_denomerator_normalized_name = ('{}_{}_tpm').format(bottom, strain)
                    
                if (top == 'rna') and (bottom == 'rna'):
                    
                    anc_numerator_normalized_name = ('{}_DGY1657_tpm').format(top)
                    evo_numerator_normalized_name = ('{}_{}_tpm').format(top, strain)
                    
                    anc_denomerator_normalized_name = ('{}_DGY1726_exp').format(top, )
                    evo_denomerator_normalized_name = ('{}_{}_tpm').format(bottom, strain)
                
                df['anc_ratio'] = (df[anc_numerator_normalized_name] / df[anc_denomerator_normalized_name])
                df['evo_ratio'] = (df[evo_numerator_normalized_name] / df[evo_denomerator_normalized_name])
                
                df['temp_eff_ratio'] = np.log2( df['evo_ratio']  / df['anc_ratio'])
                            
                pval_name = ("{strain}_{compare}_pval").format(
                    strain = strain, compare = compare)
                            
                cn_col_name = ('{}_copy_number').format(strain)
                
                df["bin"] = "ns"
                df.loc[(df[pval_name] <= 0.05) & (df[cn_col_name] == 1), "bin"] = "sig"
                df.loc[(df[pval_name] > 0.05) & (df[cn_col_name] > 1), "bin"] = "cnv_ns"
                df.loc[(df[pval_name] <= 0.05) & (df[cn_col_name] > 1), "bin"] = "cnv_sig"
                
                temp_list_ns = df[df["bin"] == "ns"]["temp_eff_ratio"].tolist()
                temp_list_sig = df[df["bin"] == "sig"]["temp_eff_ratio"].tolist()
                temp_list_cnv_sig = df[df["bin"] == "cnv_sig"]["temp_eff_ratio"].tolist()
                temp_list_cnv_ns = df[df["bin"] == "cnv_ns"]["temp_eff_ratio"].tolist()
                
                # exp_dict = df.to_dict('index')
                
                # for gene in set(['YKR008W']):
                #     #for gene in exp_dict:
                #     if gene in cn_dict:
                #         cn = cn_dict[gene][strain]
                #         padj = exp_dict[gene][pval_name] 
                #         val = exp_dict[gene]['temp_eff_ratio']
                        
                #         if cn == 1:
                #             if padj <= 0.05:
                #                 list_sig.append(val)
                #                 list_cnn.append(val)
                #             else:
                #                 list_ns.append(val)
                #                 list_cnn.append(val)
                        
                #         if cn > 1:
                #             if padj <= 0.05:
                #                 list_cnv_sig.append(val)
                #                 list_cnv.append(val)
                #             else:
                #                 list_cnv_ns.append(val)
                #                 list_cnv.append(val)
                
                list_ns+=temp_list_ns
                list_sig+=temp_list_sig
                list_cnv_sig+=temp_list_cnv_sig
                list_cnv_ns+=temp_list_cnv_ns
                
                list_cnn+=temp_list_ns
                list_cnn+=temp_list_sig
                
                list_cnv+=temp_list_cnv_sig
                list_cnv+=temp_list_cnv_ns
                    
    fig = go.Figure()

    fig.add_trace(go.Box(y=list_ns, name='NS',
                         boxpoints='all',
                         jitter=0.3,
                         pointpos=-1.8,
                         marker_color = 'grey'))
    
    fig.add_trace(go.Box(y=list_sig, name='Sig',
                         boxpoints='all',
                         jitter=0.3,
                         pointpos=-1.8,
                         marker_color = 'indianred'))
    
    fig.add_trace(go.Box(y=list_cnv_sig, name = 'CNV_sig',
                         boxpoints='all',
                         jitter=0.3,
                         pointpos=-1.8,
                         marker_color = 'blue'))
    
    fig.add_trace(go.Box(y=list_cnv_ns, name = 'CNV_ns',
                         boxpoints='all',
                         jitter=0.3,
                         pointpos=-1.8,
                         marker_color = 'grey'))
                  
    
    fig.update_layout(
        title=compare,
        xaxis_title="gene category",
        yaxis_title="Efficiency Ratio (Evo / Anc)",
        font=dict(
            size=18,
            color="Black"
        ),
        autosize=False,
        width=1000,
        height=800,
    
    )
    
    #fig.update_xaxes(range=[-4.5, 4.5])
    fig.update_yaxes(range=[-8, 8])
    
    
    fig.show()
    #fig.write_image(output_figure_name)
    #from scipy import stats

        

    #U1, p = stats.kruskal(list_cnv, list_cnn)
    
    U1, p = mannwhitneyu(list_cnv_sig, list_sig)
    #p = round(p,)
    ratio = round(np.median(list_cnv_sig)/np.median(list_sig),3)
    fc = ((np.median(list_cnv_sig)-np.median(list_sig))/np.median(list_sig))
    med_cnv = round(np.median(list_cnv_sig),3)
    med_cnn = round(np.median(list_sig),3)
    
    print('sig_cnv_v_sig_cnn', strain, compare, med_cnv, med_cnn, fc, p)
    
        #plot_log_log_scale('ms', 'rna', 'YBR169C')
    if False:
        plot_log_log_ratio('rna', 'rna')
        plot_log_log_ratio('rpf', 'rna')
        plot_log_log_ratio('ms', 'rpf')
        plot_log_log_ratio('ms', 'rna')
        

def plot_log_log_scale(top, bottom, focus_gene='YKR039W', runmode = 'all'):
    compare = ("{}_v_{}").format(top, bottom)
    
    output_figure_name = ('C:/Gresham/Project_Carolino/analyses/efficiency/{top}_to_{bottom}_efficiency_pval_{focus_gene}_{runmode}.pdf').format(
        top = top, bottom = bottom, focus_gene = focus_gene, runmode = runmode)
    
    fig = go.Figure()
    
    cnn_visibility = 0.1
    cnv_visibility = 0.33    
    
    if runmode == 'cnv_only':
        cnn_visibility = 0
        cnv_visibility = 0.33
        
    if runmode == 'cnn_only':
        cnn_visibility = 0.33
        cnv_visibility = 0
            
    for strain in set(['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']):
        if strain != 'DGY1657':
            #zscr_scalar = zscoreScaler()
            
            infile = ('C:/Gresham/Project_Carolino/analyses/efficiency/{top}_to_{bottom}_ratio_1e2.tsv').format(
                top = top, bottom = bottom) 
            df = pd.read_table(infile, index_col=0)
            
            cn_col_name = ('{}_copy_number').format(strain)
            df = df[df[cn_col_name] >= 1]
            
            if (top == 'rpf'):
                anc_numerator_normalized_name = ('{}_DGY1657_tpm').format(top)
                evo_numerator_normalized_name = ('{}_{}_tpm').format(top, strain)
                
            if (top == 'ms'):
                anc_numerator_normalized_name = ('ms_DGY1657')
                evo_numerator_normalized_name = ('ms_{}').format(strain) 
            
            if (bottom == 'rna') or (bottom == 'rpf'):
                anc_denomerator_normalized_name = ('{}_DGY1657_tpm').format(bottom)
                evo_denomerator_normalized_name = ('{}_{}_tpm').format(bottom, strain)
            
            df['anc_ratio'] = np.log2(df[anc_numerator_normalized_name] / df[anc_denomerator_normalized_name])
            df['evo_ratio'] = np.log2(df[evo_numerator_normalized_name] / df[evo_denomerator_normalized_name])
            
            max_axis = max(max(df['anc_ratio']), max(df['evo_ratio']))
            min_axis = min(min(df['anc_ratio']), min(df['evo_ratio']))
                        
            axis_wiggle = abs(max_axis-min_axis)*0.1
            
            max_axis+=axis_wiggle
            min_axis-=axis_wiggle
            
            pval_name = ("{strain}_{compare}_pval").format(
                strain = strain, compare = compare)
                        
            cn_col_name = ('{}_copy_number').format(strain)
            
            #gap1_df = df.loc["YBL075C"]
                        
            cnn_df = df[df[cn_col_name] == 1]
            
            insig_cnn_df = cnn_df[cnn_df[pval_name] > 0.05]
            #insig_cnn_index_vals = insig_cnn_df[cn_col_name].astype('category').cat.codes
            
            sig_cnn_df = cnn_df[cnn_df[pval_name] <= 0.05]
            #sig_cnn_index_vals = sig_cnn_df[cn_col_name].astype('category').cat.codes
            
            #Add insignificant cnn
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=insig_cnn_df['anc_ratio'],
                    y=insig_cnn_df['evo_ratio'],
                    text=insig_cnn_df.index + ' ' + strain,
                    marker=dict(
                        symbol = 100,
                        color = 'Grey',
                        opacity = cnn_visibility/2,
                        line=dict(
                            color='Black',
                            width=1
                        )
                    ),
                    showlegend=False
                )
            )
            
            #Add significant cnn
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=sig_cnn_df['anc_ratio'],
                    y=sig_cnn_df['evo_ratio'],
                    text=sig_cnn_df.index + ' ' + strain,
                    marker=dict(
                        symbol = 0,
                        color = "Grey",
                        opacity = cnn_visibility*2,
                        line=dict(
                            color='Black',
                            width=1
                        )
                    ),
                    showlegend=False
                )
            )
            
            any_cnv_df = df[
                (df['DGY1726_copy_number'] > 1) | 
                (df['DGY1735_copy_number'] > 1) | 
                (df['DGY1741_copy_number'] > 1) | 
                (df['DGY1743_copy_number'] > 1) ]
            
            #Add any_cnv_df run
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=any_cnv_df['anc_ratio'],
                    y=any_cnv_df['evo_ratio'],
                    text=any_cnv_df.index + ' ' + strain,
                    marker=dict(
                        symbol = 132,
                        color = 'red',
                        opacity = cnv_visibility,
                        line=dict(
                            color='Black',
                            width=1
                        )
                    ),
                    showlegend=False
                )
            )
            
            cnv_df = df[(df[cn_col_name] > 1) & (df[cn_col_name] < 3)]
            iscolor = 'Blue'
            insig_cnv_df = cnv_df[cnv_df[pval_name] > 0.05]
            #insig_cnv_index_vals = insig_cnv_df[cn_col_name].astype('category').cat.codes
            
            sig_cnv_df = cnv_df[cnv_df[pval_name] <= 0.05]
            #sig_cnv_index_vals = sig_cnv_df[cn_col_name].astype('category').cat.codes
            
            #Add insignificant cnv
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=insig_cnv_df['anc_ratio'],
                    y=insig_cnv_df['evo_ratio'],
                    text=insig_cnv_df.index + ' ' + strain,
                    marker=dict(
                        symbol = 102,
                        color = iscolor,
                        opacity = cnv_visibility,
                        line=dict(
                            color='Black',
                            width=2
                        )
                    ),
                    showlegend=False
                )
            )
            
            #Add significant cnv
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=sig_cnv_df['anc_ratio'],
                    y=sig_cnv_df['evo_ratio'],
                    text=sig_cnv_df.index + ' ' + strain,
                    marker=dict(
                        symbol = 2,
                        color = iscolor,
                        opacity = cnv_visibility*2,
                        line=dict(
                            color='Black',
                            width=1
                        )
                    ),
                    showlegend=False
                )
            )
            
            cnv_df = df[(df[cn_col_name] > 2) & (df[cn_col_name] < 4)]
            iscolor = 'Green'
            insig_cnv_df = cnv_df[cnv_df[pval_name] > 0.05]
            #insig_cnv_index_vals = insig_cnv_df[cn_col_name].astype('category').cat.codes
            
            sig_cnv_df = cnv_df[cnv_df[pval_name] <= 0.05]
            #sig_cnv_index_vals = sig_cnv_df[cn_col_name].astype('category').cat.codes
            
            #Add insignificant cnv
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=insig_cnv_df['anc_ratio'],
                    y=insig_cnv_df['evo_ratio'],
                    text=insig_cnv_df.index + ' ' + strain,
                    marker=dict(
                        symbol = 102,
                        color = iscolor,
                        opacity = cnv_visibility,
                        line=dict(
                            color='Black',
                            width=2
                        )
                    ),
                    showlegend=False
                )
            )
            
            #Add significant cnv
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=sig_cnv_df['anc_ratio'],
                    y=sig_cnv_df['evo_ratio'],
                    text=sig_cnv_df.index + ' ' + strain,
                    marker=dict(
                        symbol = 2,
                        color = iscolor,
                        opacity = cnv_visibility*2,
                        line=dict(
                            color='Black',
                            width=1
                        )
                    ),
                    showlegend=False
                )
            )
            
            cnv_df = df[(df[cn_col_name] >= 4)]
            iscolor = 'Purple'
            insig_cnv_df = cnv_df[cnv_df[pval_name] > 0.05]
            #insig_cnv_index_vals = insig_cnv_df[cn_col_name].astype('category').cat.codes
            
            sig_cnv_df = cnv_df[cnv_df[pval_name] <= 0.05]
            #sig_cnv_index_vals = sig_cnv_df[cn_col_name].astype('category').cat.codes
            
            #Add insignificant cnv
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=insig_cnv_df['anc_ratio'],
                    y=insig_cnv_df['evo_ratio'],
                    text=insig_cnv_df.index + ' ' + strain,
                    marker=dict(
                        symbol = 102,
                        color = iscolor,
                        opacity = cnv_visibility,
                        line=dict(
                            color='Black',
                            width=2
                        )
                    ),
                    showlegend=False
                )
            )
            
            #Add significant cnv
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=sig_cnv_df['anc_ratio'],
                    y=sig_cnv_df['evo_ratio'],
                    text=sig_cnv_df.index + ' ' + strain,
                    marker=dict(
                        symbol = 2,
                        color = iscolor,
                        opacity = cnv_visibility,
                        line=dict(
                            color='Black',
                            width=1
                        )
                    ),
                    showlegend=False
                )
            )
            
            #Add significant cnv
            focus_df = df.loc[focus_gene]
            
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=np.array(focus_df['anc_ratio']),
                    y=np.array(focus_df['evo_ratio']),
                    text= focus_gene + ' ' + strain,
                    marker=dict(
                        symbol = 1,
                        color = 'Red',
                        opacity = 0.69,
                        line=dict(
                            color='Black',
                            width=1
                        )
                    ),
                    showlegend=False
                )
            )
                        
    plot_title = ('{} to {} efficiencies').format(top, bottom)
    xaxis_title = ("Ancestor strain log2({} / {})").format(top, bottom)
    yaxis_title = ("Evolved strain log2({} / {})").format(top, bottom)
    
    fig.update_layout(
        title=plot_title,
        xaxis_title=xaxis_title,
        yaxis_title=yaxis_title,
        font=dict(
            size=18,
            color="Black"
        ),
        autosize=False,
        width=800,
        height=800,
    
    )

    #fig.update_xaxes(range=[-4.5, 4.5])
    #fig.update_yaxes(range=[-4.5, 4.5])
    
    fig.update_xaxes(range=[min_axis, max_axis])
    fig.update_yaxes(range=[min_axis, max_axis])
    
    fig.show()
    fig.write_image(output_figure_name)
    
    #plot_log_log_scale('ms', 'rna', 'YBR169C')
    if False:
        plot_log_log_scale('ms', 'rna', 'YDR293C')
        #plot_log_log_scale('rpf', 'rna', 'YKR039W', 'cnn_only')
    
def plot_cn(df, readtype, strain, cn_mode, fig):
    cn_col_name = ('{}_copy_number').format(strain)
    
    if cn_mode == 'cnn':
        strain_cn = df[ df[cn_col_name] == 1]
        cn_opacity = 0.1
        cn_color = strain_cn[cn_col_name].astype('category').cat.codes
        line_color = 'Black'
        yshift = 50
        
    else:
        strain_cn = df[ df[cn_col_name] != 1]
        cn_opacity = 1
        cn_color = 'Red'
        line_color = 'Red'
        yshift = 70
        
    strain_val = ('{}_{}_zscore').format(strain, readtype)
    strain_cn = strain_cn.sort_values(by=[strain_val])
    line_y = strain_cn[strain_val].to_numpy()
    
    anc_val = ("DGY1657_{}_zscore").format(readtype)
    line_x = strain_cn[anc_val].to_numpy()
    res = stats.linregress(line_x, line_y)
    
    xaxis_title = ("Ancestor {} Z-score").format(readtype)
    yaxis_title = ("Evolved {} Z-score").format(readtype)

    y_pred = []
    for x in line_x:
        y_pred.append(res.intercept + res.slope*x)
    
    fig.add_trace(
        go.Scatter(
            mode='markers',
            x=line_x,
            y=line_y,
            text=strain_cn.index,
            marker=dict(
                color=cn_color,
                opacity=cn_opacity,
                line=dict(
                    color='Black',
                    width=1
                )
            ),
            showlegend=False
        )
    )
    
    fig.add_trace(
        go.Scatter(
            mode='lines',
            x=line_x,
            y=y_pred,
            marker=dict(
                color=line_color,
                opacity=cn_opacity,
                line=dict(
                    color=line_color,
                    width=0.1,
                )
            ),
            showlegend=False
        )
    )
    
    plot_title = ('{} versus Ancestor').format(strain)
    fig.update_layout(
        title=plot_title,
        xaxis_title = xaxis_title,
        yaxis_title = yaxis_title,
        font=dict(
            size=9,
            color="Black"
        )
    )
    
    text = ('type = {cn_mode}\n'
            'slope = {slope}\n'
            'intercept = {inter}\n'
            'R2 = {r2}\n'
            'pvalue = {pval}').format(cn_mode = cn_mode,
                                      slope = round(res.slope,2),
                                      inter = round(res.intercept,2),
                                      r2 = round(res.rvalue,2),
                                      pval = round(res.pvalue,5))
    
    fig.add_annotation(text=text, showarrow=False, 
                       xref="paper", yref="paper",
                       x=1, y=1, yshift=yshift
                       )

    return(fig)

    
def plot_z_scales(top, bottom):
    infile = ('C:/Gresham/Project_Carolino/analyses/efficiency/{top}_to_{bottom}_ratio_1e3.tsv').format(
        top = top, bottom = bottom) 
        
    df = pd.read_table(infile, index_col=0)
    score_dict = df.to_dict('index')
    
    df['name'] = df.index
    for strain in set(['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']):
        cn_col_name = ('{}_copy_number').format(strain)
        
        for readtype in [top, bottom]:
            evo_score_name = ('{}_{}_zscore').format(strain, readtype)
            anc_score_name = ('DGY1657_{}_zscore').format(readtype)
            
            save_name = ('C:/Gresham/Project_Carolino/analyses/efficiency/{}_{}_zscore.pdf').format(strain, readtype)
            
            fig = go.Figure()
            fig = plot_cn(df, readtype, strain, 'cnn', fig)
            fig = plot_cn(df, readtype, strain, 'cnv', fig)
            
            cnv_list = []
            cnn_list = []
            for gene in score_dict:
                cn = score_dict[gene][cn_col_name]
                evo_score = score_dict[gene][evo_score_name]
                anc_score = score_dict[gene][anc_score_name]
                diff = evo_score - anc_score
                
                if cn != 1:
                    cnv_list.append(diff)
                
                else:
                    cnn_list.append(diff)
                    
            
            U1, p = mannwhitneyu(cnv_list, cnn_list)
            p = round(p,5)
            ratio = round(np.median(cnv_list)/np.median(cnn_list),3)
            med_cnv = round(np.median(cnv_list),3)
            med_cnn = round(np.median(cnn_list),3)
            
            print(strain, readtype, med_cnv, med_cnn, ratio, p)
            
            index_vals = df[cn_col_name].astype('category').cat.codes
            
            strain_cnn = df[ df[cn_col_name] > 1]
            fig = px.scatter(strain_cnn, 
                             x=anc_score_name, 
                             y=evo_score_name, 
                             trendline="ols",
                             hover_data=['name'])
            
            fig.show()
            
            strain_cnn = df[ df[cn_col_name] == 1]
            fig = px.scatter(strain_cnn, 
                             y=anc_score_name, 
                             x=evo_score_name, 
                             trendline="ols",
                             hover_data=['name'])
            
            fig.show()
            
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=strain_cnn[anc_score_name],
                    y=strain_cnn[evo_score_name],
                    text=strain_cnn.index,
                    marker=dict(
                        color=index_vals,
                        opacity=0.1,
                        line=dict(
                            color='Black',
                            width=1
                        )
                    ),
                    showlegend=False
                )
            )
            
            strain_cnn = df[ df[cn_col_name] > 1]
            
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=strain_cnn[anc_score_name],
                    y=strain_cnn[evo_score_name],
                    text=strain_cnn.index,
                    marker=dict(
                        color=index_vals,
                        opacity=1,
                        line=dict(
                            color='Red',
                            width=1
                        )
                    ),
                    showlegend=False
                )
            )
            
            strain_cnn = df[ df['name'] == 'YKR039W']
            
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=strain_cnn[anc_score_name],
                    y=strain_cnn[evo_score_name],
                    text='GAP1',
                    marker=dict(
                        color=index_vals,
                        opacity=1,
                        line=dict(
                            color='Green',
                            width=1
                        )
                    ),
                    showlegend=False
                )
            )
    
    
    #for strain in set(['DGY1657', 'DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']):
        
        # strain_cnn = df[ df[cn_col_name] == 1]
        # x_list=[]
        # y_list=[]
        # name_list=[]
        # for i in range(0,len(strain_cnn)):
        #     x_list.append('CNN')
        #     y_list.append(strain_cnn[evo_score_name][i])
        #     name_list.append(strain_cnn['name'][i])
            
        # fig.add_trace(go.Violin(x = x_list,
        #                         y = y_list,
        #                         text = name_list,
        #                         legendgroup='Yes', scalegroup='Yes', name = 'CNN',
        #                         side='negative',
        #                         line_color='blue')
        #              )        
        
        # strain_cnv = df[ df[cn_col_name] > 1]
        # x_list=[]
        # y_list=[]
        # name_list=[]
        # for i in range(0,len(strain_cnv)):
        #     x_list.append('CNV')
        #     y_list.append(strain_cnv[evo_score_name][i])
        #     name_list.append(strain_cnv['name'][i])
        
        # fig.add_trace(go.Violin(x = x_list,
        #                         y = y_list,
        #                         text = name_list,
        #                         legendgroup='No', scalegroup='No', name = 'CNV',
        #                         side='positive',
        #                         line_color='orange')
        #          )
    
        # #fig.update_traces(meanline_visible=True)
        # fig.update_layout(violingap=0, violinmode='overlay')
        # fig.show()
        
    
    
####

to_transform_dict = {}

#import copy_number:
copy_number_filename = ('C:/Gresham/Project_Carolino/analyses/chemostat_DESeq/chemostat_gene_relative_copy_number.tsv')
df = pd.read_table(copy_number_filename, index_col=0)
cn_dict = df.to_dict('index')


#import sizes:
infile_name = ('C:/Gresham/Project_Carolino/metadata/aa_protein_lengths.tsv')

length_df = pd.read_table(infile_name, index_col=1)
length_df['nt_length'] = length_df["aa_length"]*3
#sizes_dict = df.to_dict('index')

#import read abundances:
infile_name = ('C:/Gresham/Project_Carolino/analyses/chemostat_expression/expression_dict.tsv') 

counts_df = pd.read_table(infile_name, index_col=0)

to_transform_df = pd.merge(left = counts_df,
                           right = length_df,
                           left_index=True,
                           right_index=True)
            
to_transform_df = to_transform_df[to_transform_df["status"] == "Verified"]

for strain in ['DGY1657', 'DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
    #for RNA
    sum_col_name = ("rna_{}").format(strain)
    rep_1_name = ('CDS_RNA_{}_R1').format(strain)
    rep_2_name = ('CDS_RNA_{}_R2').format(strain)
    
    to_transform_df[sum_col_name] = (to_transform_df[rep_1_name] + to_transform_df[rep_2_name])/2
    to_transform_df = to_transform_df[to_transform_df[sum_col_name] > 1e2]
    to_transform_df = make_tpm(to_transform_df, sum_col_name, strain)
    #
    to_transform_df = make_tpm(to_transform_df, rep_1_name, strain)
    to_transform_df = make_tpm(to_transform_df, rep_2_name, strain)
    
    if strain != 'DGY1657':
        sum_col_name = ("rna_{}_exp").format(strain)
        anc_1_name = ('CDS_RNA_DGY1657_R1')
        anc_2_name = ('CDS_RNA_DGY1657_R2')
        
        to_transform_df, rep_1_tpm_name = make_exp_tpm(to_transform_df, rep_1_name, anc_1_name, strain)
        to_transform_df, rep_2_tpm_name = make_exp_tpm(to_transform_df, rep_2_name, anc_2_name, strain)
        
        to_transform_df[sum_col_name] = (to_transform_df[rep_1_tpm_name] + to_transform_df[rep_2_tpm_name])/2
        
    # for RPF
    sum_col_name = ("rpf_{}").format(strain)
    rep_1_name = ('CDS_RPF_{}_R1').format(strain)
    rep_2_name = ('CDS_RPF_{}_R2').format(strain)
    
    to_transform_df[sum_col_name] = (to_transform_df[rep_1_name] + to_transform_df[rep_2_name])/2
    to_transform_df = to_transform_df[to_transform_df[sum_col_name] > 10]
    to_transform_df = make_tpm(to_transform_df, sum_col_name, strain)
    #
    to_transform_df = make_tpm(to_transform_df, rep_1_name, strain)
    to_transform_df = make_tpm(to_transform_df, rep_2_name, strain)
    
    # if strain != 'DGY1657':
    #     anc_1_name = ('CDS_RPF_DGY1657_R1')
    #     anc_2_name = ('CDS_RPF_DGY1657_R2')
        
    #     to_transform_df = make_exp_tpm(to_transform_df, rep_1_name, anc_1_name, strain)
    #     to_transform_df = make_exp_tpm(to_transform_df, rep_2_name, anc_2_name, strain)

expected_ms_df = make_observed_ms()

ratio_df = pd.merge(left = to_transform_df,
                    right = expected_ms_df,
                    left_index = True,
                    right_index = True)

rbst_scalar = RobustScaler()
std_scalar = StandardScaler()

for compare in set(['rpf_v_rna', 'ms_v_rna', 'ms_v_rpf']):
    print(compare)
    top, bottom = compare.split('_v_')
    
    for strain in ['DGY1657', 'DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
        rna_name = ('rna_{}_tpm').format(strain)
        scale_colname = ('{}_rna_robust').format(strain)
        df_scale_val = pd.DataFrame(rbst_scalar.fit_transform(ratio_df[[rna_name]]))
        df_scale_val = df_scale_val.set_index(ratio_df.index)
        ratio_df[scale_colname] = df_scale_val 
        
        rpf_name = ('rpf_{}_tpm').format(strain)
        scale_colname = ('{}_rpf_robust').format(strain)
        df_scale_val = pd.DataFrame(rbst_scalar.fit_transform(ratio_df[[rpf_name]]))
        df_scale_val = df_scale_val.set_index(ratio_df.index)
        ratio_df[scale_colname] = df_scale_val 
    
        ms_name = ('ms_{}').format(strain)
        scale_colname = ('{}_ms_robust').format(strain)
        df_scale_val = pd.DataFrame(rbst_scalar.fit_transform(ratio_df[[ms_name]]))
        df_scale_val = df_scale_val.set_index(ratio_df.index)
        ratio_df[scale_colname] = df_scale_val
        
        
        
    ratio_dict = ratio_df.to_dict('index')
    
    sig_dict = {}
    gene_set = set()
    
    remove_set = set()
    for gene in ratio_dict:
        if gene not in cn_dict:
            remove_set.add(gene)
            
    for gene in remove_set:
        del ratio_dict[gene]
    
    for gene in ratio_dict:
    #for gene in set(['YKR034W', 'YKR039W']):
        for strain in ['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
            if (top == 'rpf'):
                anc_numerator_normalized_name = ('{}_DGY1657_tpm').format(top)
                evo_numerator_normalized_name = ('{}_{}_tpm').format(top, strain)
                
            if (top == 'ms'):
                anc_numerator_normalized_name = ('ms_DGY1657')
                evo_numerator_normalized_name = ('ms_{}').format(strain) 
            
            if (bottom == 'rna') or (bottom == 'rpf'):
                anc_denomerator_normalized_name = ('{}_DGY1657_tpm').format(bottom)
                evo_denomerator_normalized_name = ('{}_{}_tpm').format(bottom, strain)
            
        
            anc_numerator_normalized = ratio_dict[gene][anc_numerator_normalized_name]        
            evo_numerator_normalized = ratio_dict[gene][evo_numerator_normalized_name]
            #
            anc_denomerator_normalized = ratio_dict[gene][anc_denomerator_normalized_name]
            evo_denomerator_normalized = ratio_dict[gene][evo_denomerator_normalized_name]
            #print()
            odds, pval = fisher_exact([[evo_numerator_normalized, 
                                        evo_denomerator_normalized],
                                       [anc_numerator_normalized, 
                                        anc_denomerator_normalized]], alternative='two-sided')
            #print(strain, gene, pval, (evo_ms/evo_rpf_tpm)/(anc_ms/anc_rpf_tpm))
            ratio = ((evo_numerator_normalized/evo_denomerator_normalized)/
                     (anc_numerator_normalized/anc_denomerator_normalized))
            
            # odds, pval = fisher_exact([[evo_ms, evo_rpf_tpm],[anc_ms, anc_rpf_tpm]], alternative='two-sided')
            # #print(strain, gene, pval, (evo_ms/evo_rpf_tpm)/(anc_ms/anc_rpf_tpm))
            # ratio = (evo_ms/evo_rpf_tpm)/(anc_ms/anc_rpf_tpm)
            if gene in cn_dict:
                cn = cn_dict[gene][strain]
                
                copy_number_name = ("{}_copy_number").format(strain)
                
                ratio_dict[gene][copy_number_name] = cn
                
                ratio_name = ("{strain}_{compare}_ratio").format(
                    strain = strain, compare = compare)
                pval_name = ("{strain}_{compare}_pval").format(
                    strain = strain, compare = compare)
                
                
                ratio_dict[gene][ratio_name] = ratio
                ratio_dict[gene][pval_name] = pval
    
    
    outfile_name = ('C:/Gresham/Project_Carolino/analyses/efficiency/{top}_to_{bottom}_ratio_1e2.tsv').format(
        top = top, bottom = bottom) 
    ratio_df = pd.DataFrame.from_dict(ratio_dict, orient='index')
    ratio_df.to_csv(outfile_name, sep = '\t')
    

    
    plot_log_log_scale(top, bottom)

    # if (compare == 'ms_v_rna') or (compare == 'ms_v_rpf'):
    #     plot_z_scales(top, bottom)


        
def add_to_compare(gene, strain, compare, gene_cnv_top, gene_cnv_bottom, gene_cnn_top, gene_cnn_bottom, cnv_strains):
    global ratio_dict
    
    top, bottom = compare.split('_v_')
        
    if top != 'ms':
        top_name = ('{top}_{strain}_tpm').format(
            top = top, strain = strain)
        
        top_val = ratio_dict[gene][top_name]
    else:
        top_name = ('{top}_{strain}').format(
            top = top, strain = strain)
        
        top_val = ratio_dict[gene][top_name]
    
    bottom_name = ('{bottom}_{strain}_tpm').format(
        bottom = bottom, strain = strain)
    
    bottom_val = ratio_dict[gene][bottom_name]
    
    if strain != 'DGY1657':
        copy_number_name = ("{}_copy_number").format(strain)
        cn = ratio_dict[gene][copy_number_name]
            
    else:
        cn = 1
    
    if cn > 1:
        gene_cnv_top.append(top_val)
        gene_cnv_bottom.append(bottom_val)
        cnv_strains.append(strain)
        
    if cn == 1:
        gene_cnn_top.append(top_val)
        gene_cnn_bottom.append(bottom_val)
        
    return(gene_cnv_top, gene_cnv_bottom, gene_cnn_top, gene_cnn_bottom, cnv_strains)
                    
def add_to_rna_v_rna(gene, strain, gene_cnv_top, gene_cnv_bottom, gene_cnn_top, gene_cnn_bottom, cnv_strains):
    global ratio_dict
        
    top_name = ('rna_{strain}_tpm').format(strain = strain)
    
    top_val = ratio_dict[gene][top_name]
    
    if strain != 'DGY1657':
        bottom_name = ('rna_{strain}_exp').format(strain = strain)
        
        bottom_val = ratio_dict[gene][bottom_name]
        
        copy_number_name = ("{}_copy_number").format(strain)
        cn = ratio_dict[gene][copy_number_name]
        
    else:
        bottom_val = top_val
        cn = 1
    
    if cn > 1:
        gene_cnv_top.append(top_val)
        gene_cnv_bottom.append(bottom_val)
        cnv_strains.append(strain)
        
    if cn == 1:
        gene_cnn_top.append(top_val)
        gene_cnn_bottom.append(bottom_val)
    
    return(gene_cnv_top, gene_cnv_bottom, gene_cnn_top, gene_cnn_bottom, cnv_strains)
    
def add_to_dc_lists(gene, gene_list, pval_list, gene_cnv_top, gene_cnv_bottom, gene_cnn_top, gene_cnn_bottom, cnv_strains, results_dict):
        
    if len(gene_cnn_top) > 0 and len(gene_cnv_top) > 0:
        
        if gene not in results_dict:
            results_dict[gene] = ''

        gene_list.append(gene)
        
        gene_cnv_top_val = np.median(gene_cnv_top)
        gene_cnv_bottom_val = np.median(gene_cnv_bottom)
        gene_cnn_top_val = np.median(gene_cnn_top)
        gene_cnn_bottom_val = np.median(gene_cnn_bottom)
        
        _odds, p = fisher_exact([[gene_cnv_top_val, 
                                    gene_cnv_bottom_val],
                                   [gene_cnn_top_val, 
                                    gene_cnn_bottom_val]], alternative='two-sided')
        
    
        fet_pval = round(p,5)
        med_cnv = round(gene_cnv_top_val/gene_cnv_bottom_val,3)
        med_cnn = round(gene_cnn_top_val/gene_cnn_bottom_val,3)
        fet_ratio = round(med_cnv/med_cnn,3)
        
        outline = ('fet,{gene},{pval},{ratio},{med_cnv},{med_cnn},{cnv_strains}').format(
            gene = gene, pval = fet_pval, ratio = fet_ratio, med_cnv = med_cnv, 
            med_cnn = med_cnn, cnv_strains = list(cnv_strains))
        
        if fet_pval < 0.05:
            print(outline)
        
        # from scipy import stats

        # gene_cnv_list = []
        # gene_cnn_list = []
        
        # for i in range(len(gene_cnv_top)):
        #     val = gene_cnv_top[i]/gene_cnv_bottom[i]
        #     gene_cnv_list.append(val)
            
        # for i in range(len(gene_cnn_top)):
        #     val = gene_cnn_top[i]/gene_cnn_bottom[i]
        #     gene_cnn_list.append(val)
                    
        # U1, p = stats.kruskal(gene_cnv_list, gene_cnn_list)
        
        # k_pval = round(p,5)
        # med_cnv = round(np.median(gene_cnv_list),3)
        # med_cnn = round(np.median(gene_cnv_list),3)
        # fet_ratio = round(med_cnv/med_cnn,3)
        
        # koutline = ('kruskal,{gene},{pval},{ratio},{med_cnv},{med_cnn},{cnv_strains}').format(
        #     gene = gene, pval = k_pval, ratio = fet_ratio, med_cnv = med_cnv, 
        #     med_cnn = med_cnn, cnv_strains = list(cnv_strains))
        # print(koutline)
        # #U1, p = mannwhitneyu(list_cnv_sig, list_sig)
        
        # #if k_pval <0.05:
        # #    print(koutline)
        
        pval_list.append(fet_pval)
        
        results_dict[gene]=outline
        
        # if fet_pval < 0.05:
        #     print(outline)
            
    return(gene_list, pval_list, results_dict)
            
#make dosage_compensation calculation
def dosage_compensation():
    global ratio_dict
    for compare in set(['rna_v_rna']):
    
    #for compare in set(['rna_v_rna', 'rpf_v_rna', 'ms_v_rna', 'ms_v_rpf']):
        pval_list = []
        gene_list = []
        
        print(compare)
        print('dosage_compensation')
    
        outfile_name = ('C:/Gresham/Project_Carolino/analyses/dosage_compensation/dosage_compensation_FET_{}_v2.csv').format(compare)
    
        outfile = open(outfile_name, 'w')
    
        header = ('adjp,gene,pval,ratio,med_cnv,med_cnn,cnv_strains\n')
        outfile.write(header)
        
        plot_dict = {}
        
        if compare == 'rna_v_rna':
            #for gene in set(['YKR094C']):
            for gene in ratio_dict:            
                for strain in ['DGY1657', 'DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
                    gene_cnn_top = []
                    gene_cnn_bottom = []
                    gene_cnv_top = []
                    gene_cnv_bottom = []
                    cnv_strains = []
                    
                    gene_cnv_top, gene_cnv_bottom, gene_cnn_top, gene_cnn_bottom, cnv_strains = add_to_rna_v_rna(
                        gene, strain, gene_cnv_top, gene_cnv_bottom, 
                        gene_cnn_top, gene_cnn_bottom, cnv_strains)
                    
                    if gene not in plot_dict:
                        plot_dict[gene] = {}
                        
                    if strain not in plot_dict[gene]:
                        plot_dict[gene][strain] = {'gene_cnv_top':gene_cnv_top,
                                                    'gene_cnv_bottom':gene_cnv_bottom,
                                                    'gene_cnn_top': gene_cnn_top,
                                                    'gene_cnn_bottom': gene_cnn_bottom}
                        
            output_figure_name = ('C:/Gresham/Project_Carolino/analyses/dosage_compensation/rna_rna_efficiency_pval_ratio.pdf').format(
                top = top, bottom = bottom)
            
            fig = go.Figure()
            
            
                            
            if compare == 'rna_v_rna':
                for gene in set(['YKR046C']):
                    cnv_top = []
                    cnv_bottom = []
                    
                    cnn_top = []
                    cnn_bottom = []
                    
                    for strain in ['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
                        
                        infile = ('C:/Gresham/Project_Carolino/analyses/chemostat_DESeq/DESeq_Exp_RNA_DGY1657_{strain}_v2.txt').format(
                            strain = strain) 

                        if gene in cn_dict:
                            cn = cn_dict[gene][strain]
                            
                            for i in range(len(plot_dict[gene][strain]['gene_cnv_top'])):
                                exp = plot_dict[gene][strain]['gene_cnv_bottom'][i]
                                obs = plot_dict[gene][strain]['gene_cnv_top'][i]
                                cnv_top.append(obs/exp)
                                print(gene, strain, 'cnv_top', np.log2(obs/exp))
                                
                            for i in range(len(plot_dict[gene][strain]['gene_cnn_top'])):
                                exp = plot_dict[gene][strain]['gene_cnn_bottom'][i]
                                obs = plot_dict[gene][strain]['gene_cnn_top'][i]
                                cnn_top.append(obs/exp)
                                print(gene, strain, 'cnn_top', np.log2(obs/exp))
                            # cnv_bottom += plot_dict[gene][strain]['gene_cnv_bottom']
                            # cnn_top += plot_dict[gene][strain]['gene_cnn_top']
                            # cnn_bottom += plot_dict[gene][strain]['gene_cnn_bottom']
                          
    
                    fig.add_trace(go.Box(y=np.log2(cnv_top), name='cnv' + gene,
                                          boxpoints='all',
                                          jitter=0.3,
                                          pointpos=-1.8,
                                          marker_color = 'green'))
                    
                    # fig.add_trace(go.Box(y=np.log2(cnv_bottom), name='cnv_exp_' + gene,
                    #                      boxpoints='all',
                    #                      jitter=0.3,
                    #                      pointpos=-1.8,
                    #                      marker_color = 'grey'))
        
                    fig.add_trace(go.Box(y=np.log2(cnn_top), name='cnn' + gene,
                                          boxpoints='all',
                                          jitter=0.3,
                                          pointpos=-1.8,
                                          marker_color = 'blue'))
                    
                    # fig.add_trace(go.Box(y=np.log2(cnn_bottom), name='cnv_exp_'+ gene,
                    #                       boxpoints='all',
                    #                       jitter=0.3,
                    #                       pointpos=-1.8,
                    #                       marker_color = 'black'))
                      
        
                fig.update_layout(
                    title=compare,
                    xaxis_title="gene category",
                    yaxis_title="Efficiency Ratio log2(Obs / Exp)",
                    font=dict(
                        size=18,
                        color="Black"
                    ),
                    autosize=False,
                    width=1000,
                    height=800,
                
                )
                
                #fig.update_xaxes(range=[-4.5, 4.5])
                #fig.update_yaxes(range=[-1, 1])
                
                
                fig.show()
                fig.write_image(output_figure_name)
        
        results_dict = {}
                
        if compare == 'rna_v_rna':
            for gene in ratio_dict:            
                gene_cnn_top = []
                gene_cnn_bottom = []
                gene_cnv_top = []
                gene_cnv_bottom = []
                cnv_strains = []
                    
                for strain in ['DGY1657', 'DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
                    gene_cnv_top, gene_cnv_bottom, gene_cnn_top, gene_cnn_bottom, cnv_strains = add_to_rna_v_rna(
                        gene, strain, gene_cnv_top, gene_cnv_bottom, 
                        gene_cnn_top, gene_cnn_bottom, cnv_strains)
                                        
                #print(strain, gene_cnv_top, gene_cnn_top)
                gene_list, pval_list, results_dict = add_to_dc_lists(gene, gene_list, pval_list, gene_cnv_top, gene_cnv_bottom, gene_cnn_top, gene_cnn_bottom, cnv_strains, results_dict)
                

        if compare != 'rna_v_rna':
            for gene in ratio_dict:            
                gene_cnn_top = []
                gene_cnn_bottom = []
                gene_cnv_top = []
                gene_cnv_bottom = []
                cnv_strains = []
                    
                for strain in ['DGY1657', 'DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
                        gene_cnv_top, gene_cnv_bottom, gene_cnn_top, gene_cnn_bottom, cnv_strains= add_to_compare(
                            gene, strain, compare, gene_cnv_top, gene_cnv_bottom,
                            gene_cnn_top, gene_cnn_bottom, cnv_strains)

                gene_list, pval_list, results_dict = add_to_dc_lists(gene, gene_list, pval_list, gene_cnv_top, gene_cnv_bottom, gene_cnn_top, gene_cnn_bottom, cnv_strains, results_dict)
                                        
        bool_results, adj_pval_list = smt.fdrcorrection(pval_list)
        
        for i in range(len(gene_list)):
            gene = gene_list[i]
            adj_pval = adj_pval_list[i]
            
            outline = ('{adjp},{line}\n').format(
                line = results_dict[gene],
                adjp = adj_pval)
            
            outfile.write(outline)  
            
            #if adj_pval < 0.05:
                #print(outline)
                      
        outfile.close()
        
        


#make a RNA to RNA plot    
def plot_rna_rna_scale(infile_name, focus_gene='YKR039W'):
    for strain in set(['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']):
        output_figure_name = ('C:/Gresham/Project_Carolino/analyses/efficiency/{strain}_rna_v_DGY1657_rna.pdf').format(
            strain = strain)
        
        fig = go.Figure()
        
        if strain != 'DGY1657':
            df = pd.read_table(infile_name, index_col=0)
            
            cn_col_name = ('{}_copy_number').format(strain)
            df = df[df[cn_col_name] >= 1]
            
            anc_normalized_name = ('rna_DGY1657_tpm')
            evo_normalized_name = ('rna_{strain}_tpm').format(strain = strain)
            
            df['anc_value'] = np.log2(df[anc_normalized_name])
            df['evo_value'] = np.log2(df[evo_normalized_name])
            df['exp_value'] = np.log2(df[anc_normalized_name]*df[cn_col_name])
            
            max_axis = max(max(df['anc_value']), max(df['evo_value']), max(df['exp_value']))
            min_axis = min(min(df['anc_value']), min(df['evo_value']), min(df['exp_value']))
                        
            axis_wiggle = abs(max_axis-min_axis)*0.1
            
            max_axis+=axis_wiggle
            min_axis-=axis_wiggle
                                    
            cn_col_name = ('{}_copy_number').format(strain)
                                    
            cnn_df = df[df[cn_col_name] == 1]
            cnv_df = df[df[cn_col_name] >= 2]
                        
            #Add insignificant cnn
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=cnn_df['anc_value'],
                    y=cnn_df['evo_value'],
                    text=cnn_df.index + ' ' + strain,
                    marker=dict(
                        symbol = 100,
                        color = 'Grey',
                        opacity = 0.33,
                        line=dict(
                            color='Black',
                            width=1
                        )
                    ),
                    showlegend=False
                )
            )
                        
            #Add cnv_df run
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=cnv_df['anc_value'],
                    y=cnv_df['evo_value'],
                    text=cnv_df.index + ' ' + strain,
                    marker=dict(
                        symbol = 0,
                        color = 'red',
                        opacity = 0.33,
                    ),
                    showlegend=False
                )
            )
            
            #Add expected run
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=cnv_df['anc_value'],
                    y=cnv_df['exp_value'],
                    text=cnv_df.index + ' ' + strain + '_exp',
                    marker=dict(
                        symbol = 0,
                        color = 'blue',
                        opacity = 0.33,
                    ),
                    showlegend=False
                )
            )
                        
            #Add significant cnv
            focus_df = df.loc[focus_gene]
            
            fig.add_trace(
                go.Scatter(
                    mode='markers',
                    x=np.array(focus_df['anc_value']),
                    y=np.array(focus_df['evo_value']),
                    text= focus_gene + ' ' + strain,
                    marker=dict(
                        symbol = 1,
                        color = 'Red',
                        opacity = 0.69,
                    ),
                    showlegend=False
                )
            )
                        
        plot_title = ('Evovled versus Ancestor mRNA')
        xaxis_title = ("Ancestor strain log2(mRNA)")
        yaxis_title = ("{strain} log2(mRNA)").format(strain = strain)
        
        fig.update_layout(
            title=plot_title,
            xaxis_title=xaxis_title,
            yaxis_title=yaxis_title,
            font=dict(
                size=18,
                color="Black"
            ),
            autosize=False,
            width=800,
            height=800,
        
        )
        
        fig.update_xaxes(range=[min_axis, max_axis])
        fig.update_yaxes(range=[min_axis, max_axis])
        
        fig.show()
        #fig.write_image(output_figure_name)

infile_name = ('C:/Gresham/Project_Carolino/analyses/efficiency/RPF_to_RNA_ratio_1e2.tsv')
plot_rna_rna_scale(infile_name)

def eval_deseq_exp_fet(cnv_num, cnv_total, cnn_num, cnn_total):
    
    cnv_pct_is = round(100*len(cnv_num)/len(cnv_total), 3)
    cnn_pct_is = round(100*len(cnn_num)/len(cnn_total), 3)                  

    odds, pval = fisher_exact([[len(cnv_num), 
                                len(cnv_total)],
                               [len(cnn_num), 
                                len(cnn_total)]], alternative='two-sided')
    
    
    ratio = ((len(cnv_num)/len(cnv_total))/
             (len(cnn_num)/len(cnn_total)))
             
    return(cnv_pct_is, cnn_pct_is, pval, ratio)




def eval_deseq_exp():
    
    eval_set = set(list(ratio_dict.keys()))
    
    for strain in ['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
        cnv_total = set()
        cnv_up = set()
        cnv_down = set()
        
        cnn_total = set()
        cnn_up = set()
        cnn_down = set()
        
        infile_name = ('C:/Gresham/Project_Carolino/analyses/chemostat_DESeq/DESeq_Exp_RNA_DGY1657_{}_v2.txt').format(strain)

        deseq_df = pd.read_table(infile_name, index_col=0)
        deseq_dict = deseq_df.to_dict('index') 
        
        for gene in deseq_dict:
            if gene in eval_set:
                padj = deseq_dict[gene]['padj']
                l2fc = deseq_dict[gene]['log2FoldChange']
                cn = cn_dict[gene][strain]
                
                if cn > 1:
                    cnv_total.add(gene)
                    
                    if padj < 0.05:
                        if l2fc > 0:
                            cnv_up.add(gene)
                        if l2fc < 0:
                            cnv_down.add(gene)
                if cn == 1:
                    cnn_total.add(gene)
                    
                    if padj < 0.05:
                        if l2fc > 0:
                            cnn_up.add(gene)
                        if l2fc < 0:
                            cnn_down.add(gene)
                            
        cnv_pct_up, cnn_pct_up, up_pval, up_ratio = eval_deseq_exp_fet(cnv_up, cnv_total, cnn_up, cnn_total)
        cnv_pct_down, cnn_pct_down, down_pval, down_ratio = eval_deseq_exp_fet(cnv_down, cnv_total, cnn_down, cnn_total)
        
        outline = ('Strain: {strain}\n'
                   'CNV up {cnv_pct_up}% CNN up {cnn_pct_up}% {up_ratio} {up_pval}\n'
                   'CNV down {cnv_pct_down}% CNN down {cnn_pct_down}% {down_ratio} {down_pval}\n').format(strain = strain,
                                                   cnv_pct_up = cnv_pct_up,
                                                   cnv_pct_down = cnv_pct_down,
                                                   cnn_pct_up = cnn_pct_up, 
                                                   cnn_pct_down = cnn_pct_down,
                                                   up_pval = up_pval, 
                                                   up_ratio = up_ratio,
                                                   down_pval = down_pval,
                                                   down_ratio = down_ratio)
                                                       
        print(outline)
        
        for each in cnv_down:
            print(each)
        
def subset_cnv_for_deseq_obs():
    
    eval_set = set(list(ratio_dict.keys()))
    
    calc_median_dict = {}
    
    total = set()
    cnv_occurs = {}
    cnn_occurs = {}
    
    cnv = {}
    cnn = {}
    
    for strain in ['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
        if strain not in calc_median_dict:
            calc_median_dict[strain] = {'cnn': 0, 'cnv':0}
                
        infile_name = ('C:/Gresham/Project_Carolino/analyses/chemostat_DESeq/DESeq_Obs_RNA_DGY1657_{}.txt').format(strain)

        deseq_df = pd.read_table(infile_name, index_col=0)
        deseq_dict = deseq_df.to_dict('index') 
        
        for gene in deseq_dict:
            if (gene in eval_set) and (gene in cn_dict):
                padj = deseq_dict[gene]['padj']
                l2fc = deseq_dict[gene]['log2FoldChange']
                cn = cn_dict[gene][strain]
                
                total.add(gene)
                
                if cn > 1:
                    if gene not in cnv_occurs:
                        cnv_occurs[gene] = 0
                    cnv_occurs[gene] += 1 
                    
                    if padj < 0.05 and l2fc != 0:
                        if gene not in cnv:
                            cnv[gene] = 0
                            
                            
                        cnv[gene] += 1
                        
                        calc_median_dict[strain]['cnv']+=1 
                else:
                    if gene not in cnn_occurs:
                        cnn_occurs[gene] = 0
                    cnn_occurs[gene] += 1 
                    
                    if padj < 0.05 and l2fc != 0:
                        if gene not in cnn:
                            cnn[gene] = 0
                            
                        cnn[gene] += 1
                        
                        calc_median_dict[strain]['cnn']+=1 
                        
    all_cnv = set()
    all_cnn = set()
    
    for gene in cnv:
        if (cnv[gene] < cnv_occurs[gene]):
            #if cnv[gene] >= cnv_occurs[gene]:
            all_cnv.add(gene)
            
    for gene in cnn:
        if cnn[gene] >= cnn_occurs[gene]:
            all_cnn.add(gene)
         
    # for gene in cnn:
    #     if cnn[gene] >= 1:
    #         all_cnn.add(gene)
            
    for istype in ['cnv', 'cnn']:
        is_list = []
        for strain in calc_median_dict:
            is_list.append(calc_median_dict[strain][istype])
        print(istype, np.median(is_list))
        
                            
        # #pct_up, pct_down, pval, ratio = eval_deseq_exp_fet(up, total, down, total)
        
        # outline = ('Strain: {strain}\n'
        #            'Sig Diff {num_up}\n'
        #            'Up {pct_up}% Down {pct_down}% {ratio} {pval}\n').format(strain = strain,
        #                                            num_up = len(up)+len(down),
        #                                            pct_up = pct_up,
        #                                            pct_down = pct_down,
        #                                            pval = pval, 
        #                                            ratio = ratio)
                                                       
        #print(outline)
        
        
def subset_cnv_for_deseq_rpf_obs():
    
    eval_set = set(list(ratio_dict.keys()))
    
    calc_median_dict = {}
    
    total = set()
    cnv_occurs = {}
    cnn_occurs = {}
    
    cnv = {}
    cnn = {}
    
    for strain in ['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
        if strain not in calc_median_dict:
            calc_median_dict[strain] = {'cnn': 0, 'cnv':0}

                
        infile_name = ('C:/Gresham/Project_Carolino/analyses/chemostat_DESeq/DESeq_Obs_RPF_DGY1657_{}.txt').format(strain)

        deseq_df = pd.read_table(infile_name, index_col=0)
        deseq_dict = deseq_df.to_dict('index') 
        
        for gene in deseq_dict:
            if (gene in eval_set) and (gene in cn_dict):
                padj = deseq_dict[gene]['padj']
                l2fc = deseq_dict[gene]['log2FoldChange']
                cn = cn_dict[gene][strain]
                
                total.add(gene)
                
                if cn > 1:
                    if gene not in cnv_occurs:
                        cnv_occurs[gene] = 0
                    cnv_occurs[gene] += 1 
                    
                    if padj < 0.05  and l2fc != 0:
                        if gene not in cnv:
                            cnv[gene] = 0
                        cnv[gene] += 1
                        
                        calc_median_dict[strain]['cnv']+=1 
                else:
                    if gene not in cnn_occurs:
                        cnn_occurs[gene] = 0
                    cnn_occurs[gene] += 1 
                    
                    if padj < 0.05 and l2fc != 0:
                        if gene not in cnn:
                            cnn[gene] = 0
                            
                        cnn[gene] += 1
                        calc_median_dict[strain]['cnn']+=1 
                        
    all_cnv = set()
    all_cnn = set()
    
    for gene in cnv:
        #if (cnv[gene] / cnv_occurs[gene]) > 0.5:
        if (cnv[gene] < cnv_occurs[gene]):
            all_cnv.add(gene)
            
    for gene in cnn:
        if cnn[gene] >= cnn_occurs[gene]:
            all_cnn.add(gene)
            
            
    # for gene in cnn:
    #     if cnn[gene] >= 1:
    #         all_cnn.add(gene)     
            
    for istype in ['cnv', 'cnn']:
        is_list = []
        for strain in calc_median_dict:
            is_list.append(calc_median_dict[strain][istype])
        print(istype, np.median(is_list))
                
                            
def subset_cnv_welch_obs():
    
    #eval_set = set(list(ratio_dict.keys()))
    
    #total = set()
    
    calc_median_dict = {}
    
    cnv_occurs = {}
    cnn_occurs = {}
    
    cnv = {}
    cnn = {}
    
    for strain in ['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:  
        if strain not in calc_median_dict:
            calc_median_dict[strain] = {'cnn': 0, 'cnv':0}
        
        infile_name = ('C:/Gresham/Project_Carolino/analyses/perseus/Perseus_DA_Welchs_t-test_wFDR.txt')

        deseq_df = pd.read_table(infile_name, index_col="T: Majority.protein.IDs")
        deseq_dict = deseq_df.to_dict('index')
        
        padj_colname = ("N: Welch's T-test q-value {}_DGY1657").format(strain)
        l2fc_colname = ("N: Welch's T-test Difference {}_DGY1657").format(strain)
        
        for gene in deseq_dict:
            if (gene in cn_dict):
                padj = deseq_dict[gene][padj_colname]
                l2fc = deseq_dict[gene][l2fc_colname]
                cn = cn_dict[gene][strain]
                
                if cn > 1:
                    if gene not in cnv_occurs:
                        cnv_occurs[gene] = 0
                    cnv_occurs[gene] += 1 
                    
                    if padj < 0.05  and l2fc != 0:
                        if gene not in cnv:
                            cnv[gene] = 0
                        cnv[gene] += 1
                        
                        calc_median_dict[strain]['cnv']+=1
                        
                else:
                    if gene not in cnn_occurs:
                        cnn_occurs[gene] = 0
                    cnn_occurs[gene] += 1 
                    
                    if padj < 0.05 and l2fc != 0:
                        if gene not in cnn:
                            cnn[gene] = 0
                            
                        cnn[gene] += 1
                        calc_median_dict[strain]['cnn']+=1
                        
    all_cnv = set()
    all_cnn = set()
    
    for gene in cnv:
        #if (cnv[gene] / cnv_occurs[gene]) > 0.5:
        if (cnv[gene] < cnv_occurs[gene]):
            all_cnv.add(gene)
            
    for gene in cnn:
        if cnn[gene] >= cnn_occurs[gene]:
            all_cnn.add(gene)
            
    for istype in ['cnv', 'cnn']:
        is_list = []
        for strain in calc_median_dict:
            is_list.append(calc_median_dict[strain][istype])
        print(istype, np.median(is_list))
        

def subset_transcription_efficiency(top, bottom):
    
    cnv_occurs = {}
    cnn_occurs = {}
    
    cnv = {}
    cnn = {}
    

    for strain in set(['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']):
        infile = ('C:/Gresham/Project_Carolino/analyses/chemostat_DESeq/DESeq_Exp_RNA_DGY1657_{strain}_v2.txt').format(
            strain = strain) 
        df = pd.read_table(infile, index_col=0)
        exp_dict = df.to_dict('index')
        
        #outfile_name = ('C:/Gresham/Project_Carolino/analyses/efficiency/trx_{strain}_transcript_eff.csv').format(strain = strain)
        #outfile_n = open(outfile_name, 'w')
        
        
        for gene in exp_dict:
            if gene in cn_dict:
                if gene in ratio_dict:
                    cn = cn_dict[gene][strain]
                    padj = exp_dict[gene]['padj'] 
                    l2fc = exp_dict[gene]['log2FoldChange']
                    
                    # if padj < 0.05:
                    #     outline = ('{}\n').format(gene)
                    #     outfile_n.write(outline)
                    
                    if cn > 1:
                        if gene not in cnv_occurs:
                            cnv_occurs[gene] = 0
                        cnv_occurs[gene] += 1 
                        
                        if padj < 0.05 and l2fc > 0:
                            if gene not in cnv:
                                cnv[gene] = 0
                            cnv[gene] += 1
                    else:
                        if gene not in cnn_occurs:
                            cnn_occurs[gene] = 0
                        cnn_occurs[gene] += 1 
                        
                        if padj < 0.05 and l2fc != 0:
                            #outline = ('{}\n').format(gene)
                            #outfile_n.write(outline)
                            
                            if gene not in cnn:
                                cnn[gene] = 0
                                
                            cnn[gene] += 1
                            
    #outfile_n.close()
    
    all_cnv = set()
    all_cnn = set()
    
    for gene in cnv:
        #if (cnv[gene] / cnv_occurs[gene]) > 0.5:
        if (cnv[gene] >= cnv_occurs[gene]):
            all_cnv.add(gene)

    outfile_t = open('C:/Gresham/Project_Carolino/analyses/efficiency/temp_transcript_eff_cnn.csv', 'w')
    
    for gene in cnn:
        if cnn[gene] >= cnn_occurs[gene]:
            all_cnn.add(gene)
            outline = ('{}\n').format(gene)
            outfile_t.write(outline)
    outfile_t.close()
            
        
    all_cnv = set()
    all_cnn = set()
    
    for gene in cnv:
        #if (cnv[gene] / cnv_occurs[gene]) > 0.5:
        if (cnv[gene] > 1):
            all_cnv.add(gene)

    for gene in cnn:
        if cnn[gene] >= 1:
            all_cnn.add(gene)
        
def eval_deseq_obs_rna():
    
    eval_set = set(list(ratio_dict.keys()))
    
    for strain in ['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
        total = set()
        up = set()
        down = set()
                
        infile_name = ('C:/Gresham/Project_Carolino/analyses/chemostat_DESeq/DESeq_Obs_RNA_DGY1657_{}.txt').format(strain)

        deseq_df = pd.read_table(infile_name, index_col=0)
        deseq_dict = deseq_df.to_dict('index') 
        
        for gene in deseq_dict:
            if gene in eval_set:
                padj = deseq_dict[gene]['padj']
                l2fc = deseq_dict[gene]['log2FoldChange']
                
                total.add(gene)
                
                if padj < 0.05:
                    if l2fc > 0:
                        up.add(gene)
                    if l2fc < 0:
                        down.add(gene)
                            
        pct_up, pct_down, pval, ratio = eval_deseq_exp_fet(up, total, down, total)
        
        outline = ('Strain: {strain}\n'
                   'Sig Diff {num_up}\n'
                   'Up {pct_up}% Down {pct_down}% {ratio} {pval}\n').format(strain = strain,
                                                   num_up = len(up)+len(down),
                                                   pct_up = pct_up,
                                                   pct_down = pct_down,
                                                   pval = pval, 
                                                   ratio = ratio)
                                                       
        print(outline)
        
                

def eval_deseq_obs_rpf():
    
    eval_set = set(list(ratio_dict.keys()))
    
    for strain in ['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
        total = set()
        up = set()
        down = set()
                
        infile_name = ('C:/Gresham/Project_Carolino/analyses/chemostat_DESeq/DESeq_Obs_RPF_DGY1657_{}.txt').format(strain)

        deseq_df = pd.read_table(infile_name, index_col=0)
        deseq_dict = deseq_df.to_dict('index') 
        
        for gene in deseq_dict:
            if gene in eval_set:
                padj = deseq_dict[gene]['padj']
                l2fc = deseq_dict[gene]['log2FoldChange']
                
                total.add(gene)
                
                if padj < 0.05:
                    if l2fc > 0:
                        up.add(gene)
                    if l2fc < 0:
                        down.add(gene)
                            
        pct_up, pct_down, pval, ratio = eval_deseq_exp_fet(up, total, down, total)
        
        outline = ('Strain: {strain}\n'
                   'Sig Diff {num_up}\n'
                   'Up {pct_up}% Down {pct_down}% {ratio} {pval}\n').format(strain = strain,
                                                   num_up = len(up)+len(down),
                                                   pct_up = pct_up,
                                                   pct_down = pct_down,
                                                   pval = pval, 
                                                   ratio = ratio)
                                                       
        print(outline)
        
        
def eval_deseq_obs_rpf():
    
    eval_set = set(list(ratio_dict.keys()))
    
    for strain in ['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
        total = set()
        up = set()
        down = set()
                
        infile_name = ('C:/Gresham/Project_Carolino/analyses/chemostat_DESeq/DESeq_Obs_RPF_DGY1657_{}.txt').format(strain)

        deseq_df = pd.read_table(infile_name, index_col=0)
        deseq_dict = deseq_df.to_dict('index') 
        
        for gene in deseq_dict:
            if gene in eval_set:
                padj = deseq_dict[gene]['padj']
                l2fc = deseq_dict[gene]['log2FoldChange']
                
                total.add(gene)
                
                if padj < 0.05:
                    if l2fc > 0:
                        up.add(gene)
                    if l2fc < 0:
                        down.add(gene)
                            
        pct_up, pct_down, pval, ratio = eval_deseq_exp_fet(up, total, down, total)
        
        outline = ('Strain: {strain}\n'
                   'Sig Diff {num_up}\n'
                   'Up {pct_up}% Down {pct_down}% {ratio} {pval}\n').format(strain = strain,
                                                   num_up = len(up)+len(down),
                                                   pct_up = pct_up,
                                                   pct_down = pct_down,
                                                   pval = pval, 
                                                   ratio = ratio)
                                                       
        print(outline)

        
def figure_2_deseq_obs():
    
    #eval_set = set(list(ratio_dict.keys()))
    
    for strain in ['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
        cnv_total = set()
        cnv_up = set()
        cnv_down = set()
        
        cnn_total = set()
        cnn_up = set()
        cnn_down = set()
        
        infile_name = ('C:/Gresham/Project_Carolino/analyses/chemostat_DESeq/DESeq_Obs_RNA_DGY1657_{}.txt').format(strain)

        deseq_df = pd.read_table(infile_name, index_col=0)
        deseq_dict = deseq_df.to_dict('index') 
        
        for gene in deseq_dict:
            if (gene in cn_dict) and ('YKR' in gene):
                padj = deseq_dict[gene]['padj']
                l2fc = deseq_dict[gene]['log2FoldChange']
                cn = cn_dict[gene][strain]
                
                if cn > 1:
                    cnv_total.add(gene)
                    
                    if padj < 0.05:
                        if l2fc > 0:
                            cnv_up.add(gene)
                        else:
                            cnv_down.add(gene)
                if cn == 1:
                    cnn_total.add(gene)
                    
                    if padj < 0.05:
                        if l2fc > 0:
                            cnn_up.add(gene)
                        else:
                            cnn_down.add(gene)
                            
        cnv_pct_up, cnn_pct_up, up_pval, up_ratio = eval_deseq_exp_fet(cnv_up, cnv_total, cnn_up, cnn_total)
        cnv_pct_down, cnn_pct_down, down_pval, down_ratio = eval_deseq_exp_fet(cnv_down, cnv_total, cnn_down, cnn_total)
        
        outline = ('Strain: {strain}\n'
                   'CNV up {cnv_pct_up}% CNN up {cnn_pct_up}% {up_ratio} {up_pval}\n'
                   'CNV down {cnv_pct_down}% CNN down {cnn_pct_down}% {down_ratio} {down_pval}\n').format(strain = strain,
                                                   cnv_pct_up = cnv_pct_up,
                                                   cnv_pct_down = cnv_pct_down,
                                                   cnn_pct_up = cnn_pct_up, 
                                                   cnn_pct_down = cnn_pct_down,
                                                   up_pval = up_pval, 
                                                   up_ratio = up_ratio,
                                                   down_pval = down_pval,
                                                   down_ratio = down_ratio)
                                                       
        print(outline)
        

        
def eval_cnv_welch_obs():
    
    #eval_set = set(list(ratio_dict.keys()))
    
    for strain in ['DGY1726', 'DGY1735', 'DGY1741', 'DGY1743']:
        cnv_total = set()
        cnv_up = set()
        cnv_down = set()
        
        cnn_total = set()
        cnn_up = set()
        cnn_down = set()
        
        infile_name = ('C:/Gresham/Project_Carolino/analyses/perseus/Perseus_DA_Welchs_t-test_wFDR.txt')

        deseq_df = pd.read_table(infile_name, index_col="T: Majority.protein.IDs")
        deseq_dict = deseq_df.to_dict('index')
        
        padj_colname = ("N: Welch's T-test q-value {}_DGY1657").format(strain)
        l2fc_colname = ("N: Welch's T-test Difference {}_DGY1657").format(strain)
        
        for gene in deseq_dict:
            if (gene in cn_dict) and ('YKR' in gene):
                padj = deseq_dict[gene][padj_colname]
                l2fc = deseq_dict[gene][l2fc_colname]
                cn = cn_dict[gene][strain]
                
                if cn > 1:
                    cnv_total.add(gene)
                    
                    #if padj < 0.05:
                    if l2fc > 0:
                        cnv_up.add(gene)
                    if l2fc < 0:
                        cnv_down.add(gene)
                if cn == 1:
                    cnn_total.add(gene)
                    
                    #if padj < 0.05:
                    if l2fc > 0:
                        cnn_up.add(gene)
                    if l2fc < 0:
                        cnn_down.add(gene)
                        
        cnv_pct_up, cnn_pct_up, up_pval, up_ratio = eval_deseq_exp_fet(cnv_up, cnv_total, cnn_up, cnn_total)
        cnv_pct_down, cnn_pct_down, down_pval, down_ratio = eval_deseq_exp_fet(cnv_down, cnv_total, cnn_down, cnn_total)
        
        outline = ('Strain: {strain}\n'
                   'CNV up {cnv_pct_up}% CNN up {cnn_pct_up}% {up_ratio} {up_pval}\n'
                   'CNV down {cnv_pct_down}% CNN down {cnn_pct_down}% {down_ratio} {down_pval}\n').format(strain = strain,
                                                   cnv_pct_up = cnv_pct_up,
                                                   cnv_pct_down = cnv_pct_down,
                                                   cnn_pct_up = cnn_pct_up, 
                                                   cnn_pct_down = cnn_pct_down,
                                                   up_pval = up_pval, 
                                                   up_ratio = up_ratio,
                                                   down_pval = down_pval,
                                                   down_ratio = down_ratio)
                                                       
        print(outline)
        
        for each in cnv_down:
            print(each)



        
            
                
        
