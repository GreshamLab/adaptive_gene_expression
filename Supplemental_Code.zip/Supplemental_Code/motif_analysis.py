# -*- coding: utf-8 -*-
"""
Created on Thu Aug 24 20:59:02 2023

@author: pspea
"""

import numpy as np
from scipy.stats import fisher_exact
import statsmodels.stats.multitest as smt

chromo_dict = {}

n_list = ['A', 'T', 'C', 'G']
y_list = ['C', 'T']

def rev_comp(seq):
    
    compliment_dict = {'A':'T',
                       'T':'A',
                       'C':'G',
                       'G':'C'}
    
    rev_seq = seq[::-1]
    
    rev_comp_seq = ''
    
    for nt in rev_seq:
        if nt in compliment_dict:
            rev_comp_seq += compliment_dict[nt]
        else:
            rev_comp_seq += nt

    return(rev_comp_seq)

def calc_TL_fasta():
    tl_dict = {}
    
    '''
    #tab seperated
    chrVII	2778	2789	1	YGL263W	ATCGCCATAGGC
    chrVII	2781	2789	1	YGL263W	GCCATAGGC
    '''
    tl_file = open('data/TL_from_SGD.tsv')
    
    for line in tl_file:
        line = line.strip()
        chromo, start, stop, strand, gene, seq = line.split('\t')
        
        if gene not in tl_dict:
            tl_dict[gene] = seq
            
        else:
            if len(seq) > len(tl_dict[gene]):
                tl_dict[gene] = seq
    tl_file.close()  

    '''
    # {"source_attrib": "AWN", "MASK_OUT_ORFS": ["YOR302W"], "genome_files": ["/usr1/home/JUMBO/ANNOTATIONS/SGD_saccharomyces_cerevisiae.gff"], "positive_strand_end_peaks": ["/usr1/home/JUMBO/pA_bedGraph/peak_calls/total-Sc_rep1_pA_pos.bedGraph-putative_peaks-outlier_adjusted.bedGraph", "/usr1/home/JUMBO/pA_bedGraph/peak_calls/total-Sc_rep2_pA_pos.bedGraph-putative_peaks-outlier_adjusted.bedGraph"], "EFFECTIVE_LENGTH_CUTOFF": 1000, "prefix": "saccharomyces_cerevisiae", "output_dir": "/usr1/home/JUMBO/flanking_caller/20160712_generated/", "positive_strand_start_peaks": ["/usr1/home/JUMBO/TSS_bedGraph/peak_calls/total-Scer-hap-rep1_pos.bedGraph-putative_peaks-outlier_adjusted.bedGraph", "/usr1/home/JUMBO/TSS_bedGraph/peak_calls/total-Scer-hap-rep2_pos.bedGraph-putative_peaks-outlier_adjusted.bedGraph"], "negative_strand_end_peaks": ["/usr1/home/JUMBO/pA_bedGraph/peak_calls/total-Sc_rep1_pA_neg.bedGraph-putative_peaks-outlier_adjusted.bedGraph", "/usr1/home/JUMBO/pA_bedGraph/peak_calls/total-Sc_rep2_pA_neg.bedGraph-putative_peaks-outlier_adjusted.bedGraph"], "negative_strand_start_peaks": ["/usr1/home/JUMBO/TSS_bedGraph/peak_calls/total-Scer-hap-rep1_neg.bedGraph-putative_peaks-outlier_adjusted.bedGraph", "/usr1/home/JUMBO/TSS_bedGraph/peak_calls/total-Scer-hap-rep2_neg.bedGraph-putative_peaks-outlier_adjusted.bedGraph"], "exclusion_genome_files": [], "WINSORIZATION": 0.95}
    chrI	AWN	mRNA	136914	137510	.	+	.	ID=YAL008W_mRNA;PARENT=YAL008W
    chrI	AWN	gene	136914	137510	.	+	.	ID=YAL008W
    chrI	AWN	five_prime_UTR	136874	136913	.	+	.	PARENT=YAL008W_mRNA
    '''
        
    tl_file = open('data/Spealman_Naik_2018_saccharomyces_cerevisiae.gff')
    tl_bed_file_name = ('data/TL_from_SN.bed')
    tl_bed_file = open(tl_bed_file_name, 'w')
    
    for line in tl_file:
        line = line.strip()
        
        if 'five_prime_UTR' in line:
            chromo = line.split('\t')[0]
            start = int(line.split('\t')[3])
            stop =int(line.split('\t')[4])
            sign = line.split('\t')[6]
            
            gene = line.split('\t')[8].split('=')[1].split('_')[0]
            
            if gene[0] == 'Y':
            
                outline = ('{chromo}\t{start}\t{stop}\t{gene}\t1\t{sign}\n').format(
                    chromo = chromo, start = start, stop = stop, gene = gene, sign = sign)
                
                if gene not in tl_dict:
                    tl_bed_file.write(outline)
                    
                if gene in tl_dict:
                    if abs(stop-start) > len(tl_dict[gene]):
                        tl_bed_file.write(outline)
                        
    tl_file.close()
    tl_bed_file.close()
                    
    '''
    #fasta format
    >YGR131W::chrVII:754206-754725(+)
    AGCAATTGAAAGAACTGTGATTTATTTCCGCTTGTTCGAAATTATTGATGTTTAGCACTTTGCAGTAGCGACAATACAATATATGTGCTTTTAGTGCTGGGATAGTTCGTAGCTCCATTTCGGGGCGCTTGTTACATTTATTGTATATGCGCGGATGTGGCACATGCTGTTGAGATCTCACTCCTTTGGTATCTCTTTCCTGCGCCGCATTGTGCCGGCAGAATGTCGCGCTTGTATTCTCATGAACTTTTCCTCTTTACGAACCCTTTGGCGGCATGCCGTTTAAAATCTGTTGAAGATTTCCTTTACGAACAATGAGCAATGTTTTGCACAGGCAGGTGGGAAGTAGGGCCTATCGCGCCTTGGATGCAGATATAAGTATAAATATAAATTATAATAATTGGCTGTATCAGTAAATCCTTCTTGCGATGGGAGGAAGCACGATAGAGTATGTTAAGCTTTTGAGAGGCTTCATATTCATTGGAATTTTAAATAACAATAAAGCAACAACAATAATAA
    '''
    tl_file = open('data/TL_from_SN.fa')
    
    for line in tl_file:
        line = line.strip()
        
        if line[0] == '>':
            gene = line.split('>')[1].split(':')[0]
        else:
            tl_dict[gene] = line
            
    tl_file.close()  
    
    tl_fasta_file_name = ('data/TL_from_SGD_SN.fa')
    tl_fasta_file = open(tl_fasta_file_name, 'w')
                
    for gene in tl_dict:
        outline = ('>{gene}\n{seq}\n').format(
            gene = gene,
            seq = tl_dict[gene])
        tl_fasta_file.write(outline)
        
    tl_fasta_file.close()
    
    total_hit = 0
    total_length = 0
    hits_per_gene = {}
    
    for gene in tl_dict:
        seq = tl_dict[gene]
        
        total_length += len(seq)
        
        if gene not in hits_per_gene:
            hits_per_gene[gene] = 0
                        
        for nt2 in n_list:
            for nt3 in y_list:
                for nt6 in n_list:
                    for nt7 in y_list:
                        pos_search = ('C{nt2}{nt3}TC{nt6}{nt7}T').format(
                            nt2=nt2, nt3=nt3, nt6=nt6, nt7=nt7)
                        
                        count = seq.count(pos_search)
    
                        hits_per_gene[gene] += count
                        total_hit += count
    hits_list = []                    
    for gene in hits_per_gene:
        hits_list.append(hits_per_gene[gene])
        
    print(np.median(hits_list))
    print(np.mean(hits_list))
        
    background_density = total_hit/total_length
    #0.001482115619820999
    #0.0011929509649561284
    
    sig_set = set()                  
      
    SSD1_hits_file = open('data/SSD1_hits_in_TL_from_SGD_SN.txt', 'w')
    
    outline = ('#gene\thits\tlength\tobserved_density\texp_hits\tpval\tadjp\n')
    
    SSD1_hits_file.write(outline)
    
    gene_list = []
    pval_list = []
        
    for gene in tl_dict:
        length = len(tl_dict[gene])
        
        hits = hits_per_gene[gene]
        
        odds, pval = fisher_exact([[(hits), 
                                    (length)],
                                   [total_hit, total_length]], alternative='two-sided')
        
        gene_list.append(gene)
        
        if pval < 0.05:
            print(gene, hits, length)
            sig_set.add(gene)
            
        pval_list.append(pval)
        
        
    _bool, adjp_list = smt.fdrcorrection(pval_list)
    
    for i in range(len(gene_list)):
        adjp = adjp_list[i]
        gene = gene_list[i]
        pval = pval_list[i]
        
        length = len(tl_dict[gene])
        
        hits = hits_per_gene[gene]
        
        outline = ('{gene}\t{hits}\t{length}\t{density}\t{exp_hits}\t{pval}\t{adjp}\n').format(
            gene = gene, hits = hits, length = length, 
            density = round(hits/length, 3),
            exp_hits = round(background_density*length),
            pval = pval, adjp = adjp
            )
        
        SSD1_hits_file.write(outline)
        
    SSD1_hits_file.close()
        
    
    
        
        
        

        
        
        
    
    

def calc_genome_fasta():
        

    infast_file = open("C:/Gresham/genomes/SGD/S288C_reference_sequence_R64-2-1_20150113.fsa")
    
    
    
    for line in infast_file:
        '''
        >ref|NC_001133| [org=Saccharomyces cerevisiae] [strain=S288C] [moltype=genomic] [chromosome=I]
        CCACACCACACCCACACACCCACACACCACACCACACACCACACCACACCCACACACACA
        CATCCTAACACTACCCTAACACAGCCCTAATCTAACCCTGGCCAACCTGTCTCTCAACTT
        ACCCTCCATTACCCTGCCTCCACTCGTTACCCTGTCCCATTCAACCATACCACTCCGAAC
        CACCATCCATCCCTCTACTTACTACCACTCACCCACCGTTACCCTCCAATTACCCATATC
        CAACCCACTGCCACTTACCCTACCATTACCCTACCATCCACCATGACCTACTCACCATAC
        TGTTCTTCTACCCACCATATTGAAACGCTAACAAATGATCGTAAATAACACACACGTGCT
        TACCCTACCACTTTATACCACCACCACATGCCATACTCACCCTCACTTGTATACTGATTT
        '''
        line = line.strip()
        
        if line[0] == '>':
            print(line)
            if 'chromosome=' in line:
                chromo = line.split('chromosome=')[1].split(']')[0]
            else:
                chromo = 'nope'
                
            chromo_dict[chromo] = ''
            
        else:
            chromo_dict[chromo] += line
            
    infast_file.close()
    
    length = 0
    
    for chromo in chromo_dict:
        if chromo != 'nope':
            length += len(chromo_dict[chromo])
            print(length)
    
    hit_counter = {}
            
    for nt2 in n_list:
        for nt3 in y_list:
            for nt6 in n_list:
                for nt7 in y_list:
                    pos_search = ('C{nt2}{nt3}TC{nt6}{nt7}T').format(
                        nt2=nt2, nt3=nt3, nt6=nt6, nt7=nt7)
                    neg_search = rev_comp(pos_search)
                    
                    if pos_search not in hit_counter:
                        hit_counter[pos_search] = 0
                        
                    for chromo in chromo_dict:
                        if chromo != 'nope':
                            count = 0
                            count += chromo_dict[chromo].count(pos_search)
                            count += chromo_dict[chromo].count(neg_search)
                        
                            hit_counter[pos_search] += count
    
    total_hit = 0
    
    for seq in hit_counter:
        total_hit += hit_counter[seq]
        
    freq_per_nt = total_hit/(length*2)
    
    print(freq_per_nt)
    
    


                
        
        