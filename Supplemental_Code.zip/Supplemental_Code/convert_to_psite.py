# -*- coding: utf-8 -*-
"""
Created on Tue Jul 25 21:38:08 2023

@author: pspea
"""
import re
import numpy as np

import argparse

parser = argparse.ArgumentParser()
#io
parser.add_argument('-i', '--input_sam')
parser.add_argument('-o',"--output_bedgraph")

args = parser.parse_args()

sign_to_text = {'+':'plus','-':'minus'}

def reverse_complement(sequence):
    sequence = sequence.upper()
    complement = sequence.translate(str.maketrans('ATCG', 'TAGC'))
    return(complement[::-1])

def add_to_psite_dict(psite_dict, chromo, coord, weight):    
    if chromo not in psite_dict:
        psite_dict[chromo] = {}
        
    if coord not in psite_dict[chromo]:
        psite_dict[chromo][coord] = 0
        
    psite_dict[chromo][coord] += weight
    
    return(psite_dict)
    
def make_psite_fraction(psite_dict, n_sequence, chromo, start, stop, sign, size):

    size = len(n_sequence)
    offset_bins = abs(size - 28)
            
    if sign == "+":
        zero_site_coord = start + 12
        #zero_site_seq = n_sequence[12:15]
        
    if sign == "-":
        #r_sequence = reverse_complement(n_sequence)
        #print('r_sequence', r_sequence)
        zero_site_coord = stop - 13
        #zero_site_seq = r_sequence[8:11]
        
    weight =  round(1/(1+(2*offset_bins)),5)
    
    add_to_psite_dict(psite_dict, chromo, zero_site_coord, weight)
        
    for each in range(offset_bins):
        offset = each + 1
        mod_site_coord = zero_site_coord + offset 
        
        add_to_psite_dict(psite_dict, chromo, mod_site_coord, weight)
        
        mod_site_coord = zero_site_coord - offset 
        
        add_to_psite_dict(psite_dict, chromo, mod_site_coord, weight)
        
    return(psite_dict)
        
def qual_seq(sequence, poly_n=8):
    sequence = sequence.upper()
    for each_nt in ['A', 'T', 'G', 'C']:
        search_str = each_nt * poly_n
        if search_str not in sequence:
            return(True)
    
    return(False)    

def unpackbits(x,num_bits=12):
    '''
    SAM flags are bit encoded - this function seperates them and assigns labels
    '''
    
    xshape = list(x.shape)
    x = x.reshape([-1,1])
    to_and = 2**np.arange(num_bits).reshape([1,num_bits])
    upb = (x & to_and).astype(bool).astype(int).reshape(xshape + [num_bits])

    #0  (rp)    read_paired
    #1  (rmp)    read_mapped_in_proper_pair
    #2  (ru)    read_unmapped
    #3  (mu)    mate_unmapped
    #4  (rrs)    read_reverse_strand
    #5  (mrs)    mate_reverse_strand
    #6  (fip)    first_in_pair
    #7  (sip)    second_in_pair
    #8  (npa)    not_primary_alignment
    #9  (rfp)    read_fails_platform
    #10 (pcr)    read_is_PCR_or_optical_duplicate
    #11 (sa)    supplementary_alignment
    """
    strand = unpackbits(np.array([int(line.split('\t')[1])]))[0][4]
    such that 0 == '+' and 1 == '-'
    """
    
    """ DISCORDANT definition (from samblaster)
        Both side of the read pair are mapped (neither FLAG 0x4 or 0x8 is set).
        The properly paired FLAG (0x2) is not set.
        Note: We implemented an additional criteria to distinguish between strand re-orientations and distance issues
        Strand Discordant reads must be both on the same strand.
    """
        
    """ SPLIT READS
        Identify reads that have between two and --maxSplitCount [2] primary and supplemental alignments.
        Sort these alignments by their strand-normalized position along the read.
        Two alignments are output as splitters if they are adjacent on the read, and meet these criteria:
            each covers at least --minNonOverlap [20] base pairs of the read that the other does not.
            the two alignments map to different reference sequences and/or strands. 
            the two alignments map to the same sequence and strand, and represent a SV that is at least --minIndelSize [50] in length, 
            and have at most --maxUnmappedBases [50] of un-aligned base pairs between them.
        Split read alignments that are part of a duplicate read will be output unless the -e option is used.
    """
    
    return(upb) 

def parse_cigar(cigar, sequence):
    """This function calculates the offset for the read based on the match
        returns an sequence uncorrected to sign
    """

    if cigar.count('M') == 1:
        #print(cigar, sequence)
        left_cut = 0
        right_cut = 0
        
        left_list = re.split('M|S|D|I|H|N', cigar.split('M')[0])[0:-1]
        M = re.split('M|S|D|I|H|N', cigar.split('M')[0])[-1]
        right_list = re.split('M|S|D|I|H|N', cigar.split('M')[1])
        
        for each in left_list:
            if each: 
                left_cut += int(each)
                
        for each in right_list:
            if each: 
                right_cut -= int(each)
        
        n_cigar = ('{}M').format(M)

        if right_cut:
            n_sequence = sequence[left_cut:right_cut]
        else:
            n_sequence = sequence[left_cut:]
                        
        #print (left_cut, right_cut,  n_cigar, n_sequence)
        return(True, n_cigar, n_sequence)
            
    else:
        return(False, '', '')
            
def parse_sam_file(samfile_name, minsize = 20, maxsize = np.inf, match_sign = '+', reverse=False):
    psite_dict = {}
    line_ct = 0
        
    '''
    open sam file and populate read dictionary, save as pickle
    '''
    #@PG	
    #@CO
    #SRR10302098.18096714	0	I	24007	1	1M	*	0	0	A	*	NH:i:3	HI:i:1	AS:i:29	nM:i:0
    #SRR10302098.11813844	16	I	24022	1	1M	*	0	0	G	*	NH:i:3	HI:i:1	AS:i:29	nM:i:0
    #SRR10302098.19932359	16	I	24022	1	1M	*	0	0	G	*	NH:i:3	HI:i:1	AS:i:29	nM:i:0
        
    strand_to_sign = {0:'+', 1:'-'}
    if reverse:
        strand_to_sign = {0:'-', 1:'+'}
    
    samfile = open(samfile_name)
    print('Processing sam file ...', samfile_name)
    
    #adjusted_sam_file_name = samfile_name.split('.sam')[0] + '_psite_adj.sam'
    #adjusted_sam_file = open(adjusted_sam_file_name, 'w')

    for line in samfile:
        if (line_ct >= 1e6) and (line_ct % 1e6) == 0:
            print('Processing ', line_ct)
        # if line[0] == '@':
        #     adjusted_sam_file.write(line)
                    
        if line[0] != '@':
            line_ct += 1
            # 30nt + 'A00354:331:HKTHNDSXY:4:1222:2835:14669'
            # 28nt + 'A00354:331:HKTHNDSXY:4:2204:32009:2065'
            # 27nt + 'A00354:331:HKTHNDSXY:4:2175:20998:19132'
            # 28nt - 'A00354:331:HKTHNDSXY:4:2664:28311:9126'
            # 27nt - 'A00354:331:HKTHNDSXY:4:1135:19985:4539'
            # 31nt - 'A00354:331:HKTHNDSXY:4:2462:6506:15577'
            # raw_uid = line.split('\t')[0]
            # if raw_uid == 'A00354:331:HKTHNDSXY:4:2462:6506:15577':
            #     print(line)
            
            chromo = line.split('\t')[2]
                                    
            mapq = int(line.split('\t')[4])
            cigar = line.split('\t')[5]
            sequence = line.split('\t')[9]

            ### short read rna and rpf 
            process, n_cigar, n_sequence = parse_cigar(cigar, sequence)
            
            if (process) and (mapq >= 1):
                sign = strand_to_sign[unpackbits(np.array([int(line.split('\t')[1])]))[0][4]]

                start = int(line.split('\t')[3])
                size = len(n_sequence)
                stop = start + size

                #filter by size
                #if size >= 28 and size <= 28:                
                if size >= minsize and size <= maxsize and sign == match_sign:
                    if qual_seq(n_sequence):
                       psite_dict = make_psite_fraction(psite_dict, n_sequence, chromo, start, stop, sign, size)
                            
    return(psite_dict)

def make_bedgraph(psite_dict, runsize, match_sign):
    sign = sign_to_text[match_sign]
    
    outfile_name = ('{output}_{runsize}_{sign}.bedgraph').format(
        output = args.output_bedgraph,
        runsize = runsize,
        sign = sign)
    outfile = open(outfile_name, 'w')
    
    print('making bedgraph: ', outfile_name)
    
    for chromo in psite_dict:
        min_nt = min(psite_dict[chromo])
        max_nt = max(psite_dict[chromo])
        
        for nt in range(min_nt, max_nt+1):
            if nt in psite_dict[chromo]:
                outline = ('{chromo}\t{start}\t{stop}\t{score}\n').format(
                    chromo = chromo,
                    start = nt-1,
                    stop = nt,
                    score = psite_dict[chromo][nt])
                #print(outline)
                outfile.write(outline)
                
    outfile.close()
                
def launch():
    
    #only 28mers
    minsize = 28
    maxsize = 28
    
    match_sign = '+'
    
    psite_dict = parse_sam_file(args.input_sam, minsize, maxsize, match_sign)
    make_bedgraph(psite_dict, '28nt', match_sign)
    
    match_sign = '-'
    psite_dict = parse_sam_file(args.input_sam, minsize, maxsize, match_sign)
    make_bedgraph(psite_dict, '28nt', match_sign)
    
    #20+
    minsize = 20
    maxsize = np.inf
    
    match_sign = '+'
    psite_dict = parse_sam_file(args.input_sam, minsize, maxsize, match_sign)
    make_bedgraph(psite_dict, 'all', match_sign)
    
    match_sign = '-'
    psite_dict = parse_sam_file(args.input_sam, minsize, maxsize, match_sign)
    make_bedgraph(psite_dict, 'all', match_sign)
      
launch()

